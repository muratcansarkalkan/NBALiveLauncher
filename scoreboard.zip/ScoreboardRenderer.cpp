#include "ScoreboardRenderer.h"
#include "PopupFont.h"
#include "PopupTheme.h"
#include "ScoreboardConfig.h"

#include <cstdio>
#include <cstring>
#include <cmath>
#include <cctype>
#include <cstdlib>

namespace scoreboard {
namespace {

struct ScreenVertex {
    float x, y, z, rhw;
    D3DCOLOR color;
};

void DrawFilledRect(IDirect3DDevice9* device, float left, float top,
                    float right, float bottom, D3DCOLOR color)
{
    const ScreenVertex vertices[4] = {
        { left,  top,    0.0f, 1.0f, color },
        { right, top,    0.0f, 1.0f, color },
        { left,  bottom, 0.0f, 1.0f, color },
        { right, bottom, 0.0f, 1.0f, color }
    };
    device->SetTexture(0, nullptr);
    device->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE);
    device->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertices,
        sizeof(ScreenVertex));
}

void DrawGradientRect(IDirect3DDevice9* device, float left, float top,
                      float right, float bottom, D3DCOLOR start,
                      D3DCOLOR end, bool horizontal)
{
    const D3DCOLOR tl = start;
    const D3DCOLOR tr = horizontal ? end : start;
    const D3DCOLOR bl = horizontal ? start : end;
    const D3DCOLOR br = end;
    const ScreenVertex vertices[4] = {
        { left, top, 0.0f, 1.0f, tl }, { right, top, 0.0f, 1.0f, tr },
        { left, bottom, 0.0f, 1.0f, bl }, { right, bottom, 0.0f, 1.0f, br }
    };
    device->SetTexture(0, nullptr);
    device->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE);
    device->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertices,
        sizeof(ScreenVertex));
}

void DrawFilledCircle(IDirect3DDevice9* device, float centerX,
                      float centerY, float radius, D3DCOLOR color)
{
    constexpr int SEGMENTS = 20;
    constexpr float TWO_PI = 6.28318530717958647692f;
    ScreenVertex vertices[SEGMENTS + 2] = {};
    vertices[0] = { centerX, centerY, 0.0f, 1.0f, color };
    for (int i = 0; i <= SEGMENTS; ++i) {
        const float angle = TWO_PI * static_cast<float>(i) /
            static_cast<float>(SEGMENTS);
        vertices[i + 1] = {
            centerX + std::cos(angle) * radius,
            centerY + std::sin(angle) * radius,
            0.0f, 1.0f, color
        };
    }
    device->SetTexture(0, nullptr);
    device->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE);
    device->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, SEGMENTS, vertices,
        sizeof(ScreenVertex));
}

struct TextureVertex {
    float x, y, z, rhw;
    D3DCOLOR color;
    float u, v;
};

void DrawTexture(IDirect3DDevice9* device, IDirect3DTexture9* texture,
                 float left, float top, float right, float bottom,
                 D3DCOLOR color = 0xFFFFFFFFu,
                 bool replaceRgb = false)
{
    if (!texture) return;
    D3DSURFACE_DESC description = {};
    if (FAILED(texture->GetLevelDesc(0, &description)) ||
        !description.Width || !description.Height)
        return;

    const float availableWidth = right - left;
    const float availableHeight = bottom - top;
    const float imageAspect = static_cast<float>(description.Width) /
        static_cast<float>(description.Height);
    const float boxAspect = availableWidth / availableHeight;
    if (imageAspect > boxAspect) {
        const float height = availableWidth / imageAspect;
        top += (availableHeight - height) * 0.5f;
        bottom = top + height;
    }
    else {
        const float width = availableHeight * imageAspect;
        left += (availableWidth - width) * 0.5f;
        right = left + width;
    }

    const TextureVertex vertices[4] = {
        { left,  top,    0.0f, 1.0f, color, 0.0f, 0.0f },
        { right, top,    0.0f, 1.0f, color, 1.0f, 0.0f },
        { left,  bottom, 0.0f, 1.0f, color, 0.0f, 1.0f },
        { right, bottom, 0.0f, 1.0f, color, 1.0f, 1.0f }
    };
    device->SetTexture(0, texture);
    device->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1);
    device->SetTextureStageState(0, D3DTSS_COLOROP,
        replaceRgb ? D3DTOP_SELECTARG2 : D3DTOP_MODULATE);
    device->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    device->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
    device->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
    device->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
    device->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
    device->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertices,
        sizeof(TextureVertex));
}

void DrawTextureStretched(IDirect3DDevice9* device,
                          IDirect3DTexture9* texture,
                          float left, float top, float right, float bottom,
                          D3DCOLOR color, bool replaceRgb = false)
{
    if (!texture) return;
    const TextureVertex vertices[4] = {
        { left,  top,    0.0f, 1.0f, color, 0.0f, 0.0f },
        { right, top,    0.0f, 1.0f, color, 1.0f, 0.0f },
        { left,  bottom, 0.0f, 1.0f, color, 0.0f, 1.0f },
        { right, bottom, 0.0f, 1.0f, color, 1.0f, 1.0f }
    };
    device->SetTexture(0, texture);
    device->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1);
    device->SetTextureStageState(0, D3DTSS_COLOROP,
        replaceRgb ? D3DTOP_SELECTARG2 : D3DTOP_MODULATE);
    device->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    device->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
    device->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
    device->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
    device->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
    device->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertices,
        sizeof(TextureVertex));
}

void DrawSevenSegmentDigit(IDirect3DDevice9* device, int digit,
                           float x, float y, float width, float height,
                           float thickness, D3DCOLOR color)
{
    static const unsigned char masks[10] = {
        0x3F, 0x06, 0x5B, 0x4F, 0x66,
        0x6D, 0x7D, 0x07, 0x7F, 0x6F
    };
    if (digit < 0 || digit > 9) return;
    const unsigned char mask = masks[digit];
    const float middle = y + height * 0.5f;
    if (mask & 0x01)
        DrawFilledRect(device, x, y, x + width, y + thickness, color);
    if (mask & 0x02)
        DrawFilledRect(device, x + width - thickness, y,
            x + width, middle, color);
    if (mask & 0x04)
        DrawFilledRect(device, x + width - thickness, middle,
            x + width, y + height, color);
    if (mask & 0x08)
        DrawFilledRect(device, x, y + height - thickness,
            x + width, y + height, color);
    if (mask & 0x10)
        DrawFilledRect(device, x, middle, x + thickness,
            y + height, color);
    if (mask & 0x20)
        DrawFilledRect(device, x, y, x + thickness, middle, color);
    if (mask & 0x40)
        DrawFilledRect(device, x, middle - thickness * 0.5f,
            x + width, middle + thickness * 0.5f, color);
}

float DrawInteger(IDirect3DDevice9* device, unsigned int value,
                  float right, float y, float digitWidth, float digitHeight,
                  float spacing, D3DCOLOR color)
{
    char text[16];
    std::sprintf(text, "%u", value);
    const size_t length = std::strlen(text);
    const float total = length * digitWidth + (length - 1) * spacing;
    float x = right - total;
    for (size_t i = 0; i < length; ++i) {
        DrawSevenSegmentDigit(device, text[i] - '0', x, y,
            digitWidth, digitHeight, 3.0f, color);
        x += digitWidth + spacing;
    }
    return right - total;
}

float ClockCharacterWidth(char character, float digitWidth)
{
    if (character == ':') return 7.0f;
    if (character == '.') return 6.0f;
    return digitWidth;
}

void DrawClockText(IDirect3DDevice9* device, const char* text,
                   float centerX, float y, D3DCOLOR color)
{
    const float digitWidth = 13.0f;
    const float digitHeight = 28.0f;
    const float spacing = 4.0f;
    float total = 0.0f;
    for (const char* p = text; *p; ++p)
        total += ClockCharacterWidth(*p, digitWidth) + spacing;
    total -= spacing;

    float x = centerX - total * 0.5f;
    for (const char* p = text; *p; ++p) {
        if (*p == ':') {
            DrawFilledRect(device, x + 2.0f, y + 8.0f,
                x + 5.0f, y + 11.0f, color);
            DrawFilledRect(device, x + 2.0f, y + 19.0f,
                x + 5.0f, y + 22.0f, color);
        }
        else if (*p == '.') {
            DrawFilledRect(device, x + 1.0f, y + digitHeight - 4.0f,
                x + 5.0f, y + digitHeight, color);
        }
        else {
            DrawSevenSegmentDigit(device, *p - '0', x, y,
                digitWidth, digitHeight, 3.0f, color);
        }
        x += ClockCharacterWidth(*p, digitWidth) + spacing;
    }
}

void DrawGameClock(IDirect3DDevice9* device, unsigned int rawClock,
                   unsigned int unitsPerSecond, float centerX, float y,
                   D3DCOLOR color)
{
    char text[16];
    const unsigned int totalTenths =
        (rawClock * 10u + unitsPerSecond - 1u) / unitsPerSecond;
    if (totalTenths < 600u) {
        std::sprintf(text, "%u.%u",
            totalTenths / 10u, totalTenths % 10u);
    }
    else {
        const unsigned int totalSeconds = rawClock / unitsPerSecond;
        std::sprintf(text, "%u:%02u",
            totalSeconds / 60u, totalSeconds % 60u);
    }
    DrawClockText(device, text, centerX, y, color);
}

scoreboardconfig::Rect ToScreen(const scoreboardconfig::Rect& source,
                                float originX, float originY, float scale)
{
    scoreboardconfig::Rect result = {
        originX + source.x * scale,
        originY + source.y * scale,
        source.width * scale,
        source.height * scale
    };
    return result;
}

void FormatPeriod(int zeroBasedQuarter,
                  scoreboardconfig::PeriodFormat format,
                  char* output, size_t capacity)
{
    if (zeroBasedQuarter >= 4) {
        const int overtime = zeroBasedQuarter - 3;
        if (overtime == 1) std::snprintf(output, capacity, "OT");
        else std::snprintf(output, capacity, "%dOT", overtime);
        return;
    }
    const int quarter = zeroBasedQuarter + 1;
    const char* ordinal = quarter == 1 ? "1st" : quarter == 2 ?
        "2nd" : quarter == 3 ? "3rd" : "4th";
    switch (format) {
    case scoreboardconfig::PeriodFormat::Number:
        std::snprintf(output, capacity, "%d", quarter); break;
    case scoreboardconfig::PeriodFormat::OrdinalQuarter:
        std::snprintf(output, capacity, "%s Qtr", ordinal); break;
    case scoreboardconfig::PeriodFormat::ShortQuarter:
        std::snprintf(output, capacity, "Q%d", quarter); break;
    case scoreboardconfig::PeriodFormat::LongQuarter:
        std::snprintf(output, capacity, "%s Quarter", ordinal); break;
    default:
        std::snprintf(output, capacity, "%s", ordinal); break;
    }
}

void TransformText(const char* source, scoreboardconfig::TextTransform transform,
                   char* output, size_t capacity)
{
    if (!output || !capacity) return;
    size_t i = 0;
    bool wordStart = true;
    for (; source && source[i] && i + 1 < capacity; ++i) {
        const unsigned char c = static_cast<unsigned char>(source[i]);
        if (transform == scoreboardconfig::TextTransform::Uppercase)
            output[i] = static_cast<char>(std::toupper(c));
        else if (transform == scoreboardconfig::TextTransform::Lowercase)
            output[i] = static_cast<char>(std::tolower(c));
        else if (transform == scoreboardconfig::TextTransform::Capitalize) {
            output[i] = static_cast<char>(wordStart ? std::toupper(c) : std::tolower(c));
            wordStart = !std::isalnum(c);
        }
        else output[i] = source[i];
    }
    output[i] = '\0';
}

float MeasureSmallCaps(const char* text, float height, float smallScale)
{
    float width = 0.0f;
    for (const unsigned char* p = reinterpret_cast<const unsigned char*>(text);
         p && *p; ++p) {
        char glyph[2] = { static_cast<char>(std::islower(*p) ?
            std::toupper(*p) : *p), '\0' };
        width += popupfont::Measure(glyph,
            std::islower(*p) ? height * smallScale : height);
    }
    return width;
}

void DrawSmallCapsLeft(IDirect3DDevice9* device, const char* text,
                       float x, float y, float height, float smallScale,
                       D3DCOLOR color)
{
    for (const unsigned char* p = reinterpret_cast<const unsigned char*>(text);
         p && *p; ++p) {
        const bool isSmallCap = std::islower(*p) != 0;
        const float glyphHeight = isSmallCap ? height * smallScale : height;
        char glyph[2] = { static_cast<char>(isSmallCap ?
            std::toupper(*p) : *p), '\0' };
        popupfont::DrawLeft(device, glyph, x, y + height - glyphHeight,
            glyphHeight, color);
        x += popupfont::Measure(glyph, glyphHeight);
    }
}

void DrawBoundText(IDirect3DDevice9* device, const char* sourceText,
                   const scoreboardconfig::Rect& rectangle,
                   float height, D3DCOLOR color, int alignment,
                   bool fit = false,
                   scoreboardconfig::TextTransform transform =
                       scoreboardconfig::TextTransform::None,
                   float smallCapsScale = 0.75f)
{
    char transformed[128] = {};
    TransformText(sourceText, transform, transformed, sizeof(transformed));
    const char* text = transformed;
    // The rectangle is an alignment box, not a font-size ceiling. Keeping
    // the requested height allows the editor's score/clock/shot-clock font
    // controls to grow text beyond the original default element bounds.
    float actualHeight = height > 0.0f ? height : rectangle.height;
    if (fit && rectangle.height > 0.0f && actualHeight > rectangle.height)
        actualHeight = rectangle.height;
    if (fit && rectangle.width > 0.0f) {
        const float measured = transform == scoreboardconfig::TextTransform::SmallCaps ?
            MeasureSmallCaps(sourceText, actualHeight, smallCapsScale) :
            popupfont::Measure(text, actualHeight);
        if (measured > rectangle.width && measured > 0.0f)
            actualHeight *= rectangle.width / measured;
    }
    const float y = rectangle.y +
        (rectangle.height - actualHeight) * 0.5f;
    if (transform == scoreboardconfig::TextTransform::SmallCaps) {
        const float measured = MeasureSmallCaps(sourceText, actualHeight,
            smallCapsScale);
        const float x = alignment < 0 ? rectangle.x : alignment > 0 ?
            rectangle.x + rectangle.width - measured :
            rectangle.x + (rectangle.width - measured) * 0.5f;
        DrawSmallCapsLeft(device, sourceText, x, y, actualHeight,
            smallCapsScale, color);
        return;
    }
    if (alignment < 0)
        popupfont::DrawLeft(device, text, rectangle.x, y,
            actualHeight, color);
    else if (alignment > 0)
        popupfont::DrawRight(device, text,
            rectangle.x + rectangle.width, y, actualHeight, color);
    else
        popupfont::DrawCentered(device, text,
            rectangle.x + rectangle.width * 0.5f,
            y, actualHeight, color);
}

D3DCOLOR WithOpacity(D3DCOLOR color, int opacity)
{
    if (opacity < 0) opacity = 0;
    if (opacity > 255) opacity = 255;
    return (static_cast<D3DCOLOR>(opacity) << 24) | (color & 0x00FFFFFFu);
}

D3DCOLOR ResolveLayerColor(const char* binding, D3DCOLOR fallback,
                           const scoreboard::Frame& frame, int opacity)
{
    D3DCOLOR color = fallback;
    if (binding && std::strcmp(binding, "away.primaryColor") == 0)
        color = frame.awayColor;
    else if (binding && std::strcmp(binding, "home.primaryColor") == 0)
        color = frame.homeColor;
    else if (binding && std::strcmp(binding, "away.secondaryColor") == 0)
        color = frame.awaySecondaryColor;
    else if (binding && std::strcmp(binding, "home.secondaryColor") == 0)
        color = frame.homeSecondaryColor;
    else if (binding && std::strcmp(binding, "violation.teamColor") == 0)
        color = frame.violationTeamColor;
    else if (binding && std::strcmp(binding, "playcall.teamColor") == 0)
        color = frame.playCallTeamColor;
    else if (binding && std::strcmp(binding, "stat.teamColor") == 0)
        color = frame.statTeamColor;
    else if (binding && std::strcmp(binding, "stat.primaryColor") == 0)
        color = frame.statPrimaryColor;
    else if (binding && std::strcmp(binding, "stat.secondaryColor") == 0)
        color = frame.statSecondaryColor;
    else if (binding && std::strcmp(binding, "starting5.teamColor") == 0)
        color = frame.starting5TeamColor;
    else if (binding && std::strcmp(binding, "starting5.primaryColor") == 0)
        color = frame.starting5PrimaryColor;
    else if (binding && std::strcmp(binding, "starting5.secondaryColor") == 0)
        color = frame.starting5SecondaryColor;
    else if (binding && std::strcmp(binding, "outro.awayPrimaryColor") == 0)
        color = frame.awayColor;
    else if (binding && std::strcmp(binding, "outro.homePrimaryColor") == 0)
        color = frame.homeColor;
    else if (binding && std::strcmp(binding, "outro.awaySecondaryColor") == 0)
        color = frame.awaySecondaryColor;
    else if (binding && std::strcmp(binding, "outro.homeSecondaryColor") == 0)
        color = frame.homeSecondaryColor;
    else if (binding && std::strcmp(binding, "lineups.awayPrimaryColor") == 0)
        color = frame.awayColor;
    else if (binding && std::strcmp(binding, "lineups.homePrimaryColor") == 0)
        color = frame.homeColor;
    else if (binding && std::strcmp(binding, "lineups.awaySecondaryColor") == 0)
        color = frame.awaySecondaryColor;
    else if (binding && std::strcmp(binding, "lineups.homeSecondaryColor") == 0)
        color = frame.homeSecondaryColor;
    return WithOpacity(color, opacity);
}

void DrawIndicator(IDirect3DDevice9* device,
                   scoreboardconfig::IndicatorMode mode,
                   const scoreboardconfig::Rect& rectangle,
                   int value, int maximum, const char* label,
                   IDirect3DTexture9* image, D3DCOLOR color,
                   float textHeight);

bool ResolveLayerText(const scoreboardconfig::Element& element,
                      const scoreboardconfig::Config& config,
                      const scoreboard::Frame& frame,
                      char* output, size_t capacity,
                      float* defaultHeight,
                      const popupfont::Style& style,
                      D3DCOLOR* color)
{
    if (element.textTemplate[0]) {
        output[0] = '\0';
        *color = style.scoreColor;
        *defaultHeight = style.teamNameHeight;
        size_t written = 0;
        const char* source = element.textTemplate;
        for (size_t i = 0; source[i] && written + 1 < capacity;) {
            if (source[i] == '{' && source[i + 1] == '{') {
                output[written++] = '{'; i += 2; continue;
            }
            if (source[i] == '}' && source[i + 1] == '}') {
                output[written++] = '}'; i += 2; continue;
            }
            if (source[i] != '{') {
                output[written++] = source[i++]; continue;
            }
            const char* close = std::strchr(source + i + 1, '}');
            if (!close) {
                output[written++] = source[i++]; continue;
            }
            const size_t keyLength = static_cast<size_t>(close - (source + i + 1));
            if (!keyLength || keyLength >= sizeof(element.binding)) {
                i = static_cast<size_t>(close - source) + 1; continue;
            }
            scoreboardconfig::Element token = element;
            std::memset(token.binding, 0, sizeof(token.binding));
            std::memcpy(token.binding, source + i + 1, keyLength);
            token.text[0] = '\0';
            token.textTemplate[0] = '\0';
            char value[128] = {};
            float tokenHeight = *defaultHeight;
            D3DCOLOR tokenColor = *color;
            if (ResolveLayerText(token, config, frame, value, sizeof(value),
                    &tokenHeight, style, &tokenColor)) {
                const size_t available = capacity - written - 1;
                const size_t valueLength = std::strlen(value);
                const size_t copyLength = valueLength < available ?
                    valueLength : available;
                std::memcpy(output + written, value, copyLength);
                written += copyLength;
                *defaultHeight = tokenHeight;
                *color = tokenColor;
            }
            i = static_cast<size_t>(close - source) + 1;
        }
        output[written] = '\0';
        return true;
    }
    const char* b = element.binding;
    *color = style.scoreColor;
    *defaultHeight = style.teamNameHeight;
    if (!b[0]) { std::snprintf(output, capacity, "%s", element.text); return true; }
    if (std::strcmp(b, "violation.title") == 0) {
        std::snprintf(output, capacity, "%s",
            frame.violationTitle ? frame.violationTitle : "");
        *defaultHeight = style.scoreHeight; return true;
    }
    if (std::strcmp(b, "violation.possession") == 0) {
        std::snprintf(output, capacity, "%s",
            frame.violationPossession ? frame.violationPossession : "");
        *defaultHeight = style.teamNameHeight; return true;
    }
    if (std::strcmp(b, "violation.teamName") == 0) {
        std::snprintf(output, capacity, "%s",
            frame.violationTeamName ? frame.violationTeamName : "");
        *defaultHeight = style.teamNameHeight; return true;
    }
    if (std::strcmp(b, "playcall.team") == 0) {
        std::snprintf(output, capacity, "%s",
            frame.playCallTeam ? frame.playCallTeam : "");
        *defaultHeight = style.teamNameHeight;
        return true;
    }
    if (std::strcmp(b, "playcall.call") == 0) {
        std::snprintf(output, capacity, "%s",
            frame.playCallName ? frame.playCallName : "");
        *defaultHeight = style.teamNameHeight;
        return true;
    }
    if (std::strncmp(b, "playcall.raw", 12) == 0) {
        const char* indexText = b + 12;
        char* end = nullptr;
        const long index = std::strtol(indexText, &end, 10);
        if (end != indexText && *end == '\0' && index >= 0 && index < 4) {
            std::snprintf(output, capacity, "%s",
                frame.playCallValues[index] ? frame.playCallValues[index] : "");
        }
        else output[0] = '\0';
        *defaultHeight = style.teamNameHeight;
        return true;
    }
    if (std::strncmp(b, "intro.raw", 9) == 0) {
        const char* indexText = b + 9;
        char* end = nullptr;
        const long index = std::strtol(indexText, &end, 10);
        if (end != indexText && *end == '\0' && index >= 0 && index < 15)
            std::snprintf(output, capacity, "%s",
                frame.introValues[index] ? frame.introValues[index] : "");
        else output[0] = '\0';
        *defaultHeight = style.teamNameHeight;
        return true;
    }
    struct IntroBinding { const char* name; int index; };
    static const IntroBinding introBindings[] = {
        { "intro.homeHeading", 0 }, { "intro.awayCity", 1 },
        { "intro.awayNickname", 2 }, { "intro.awayRecord", 3 },
        { "intro.homeCity", 4 }, { "intro.homeNickname", 5 },
        { "intro.homeRecord", 6 }, { "intro.liveFromHeading", 7 },
        { "intro.arena", 8 }, { "intro.location", 9 },
        { "intro.homeNumeric", 10 }, { "intro.awayNumeric", 11 },
        { "intro.awayTeamCode", 12 }, { "intro.homeTeamCode", 13 },
        { "intro.leagueCode", 14 }
    };
    for (unsigned int i = 0;
         i < sizeof(introBindings) / sizeof(introBindings[0]); ++i) {
        if (std::strcmp(b, introBindings[i].name) == 0) {
            const char* value = frame.introValues[introBindings[i].index];
            std::snprintf(output, capacity, "%s", value ? value : "");
            *defaultHeight = style.teamNameHeight;
            return true;
        }
    }
    if (std::strncmp(b, "starting5.raw", 13) == 0) {
        const char* indexText = b + 13;
        char* end = nullptr;
        const long index = std::strtol(indexText, &end, 10);
        if (end != indexText && *end == '\0' && index >= 0 && index < 11)
            std::snprintf(output, capacity, "%s",
                frame.starting5Values[index] ? frame.starting5Values[index] : "");
        else output[0] = '\0';
        *defaultHeight = style.teamNameHeight;
        return true;
    }
    struct Starting5Binding { const char* name; int index; };
    static const Starting5Binding starting5Bindings[] = {
        { "starting5.player1Id", 0 }, { "starting5.player2Id", 1 },
        { "starting5.player3Id", 2 }, { "starting5.player4Id", 3 },
        { "starting5.player5Id", 4 }, { "starting5.player1Name", 5 },
        { "starting5.player2Name", 6 }, { "starting5.player3Name", 7 },
        { "starting5.player4Name", 8 }, { "starting5.player5Name", 9 },
        { "starting5.teamCode", 10 }
    };
    for (unsigned int i = 0;
         i < sizeof(starting5Bindings) / sizeof(starting5Bindings[0]); ++i) {
        if (std::strcmp(b, starting5Bindings[i].name) == 0) {
            const char* value = frame.starting5Values[starting5Bindings[i].index];
            std::snprintf(output, capacity, "%s", value ? value : "");
            *defaultHeight = style.teamNameHeight;
            return true;
        }
    }
    if (std::strcmp(b, "starting5.teamName") == 0 ||
        std::strcmp(b, "starting5.side") == 0) {
        const char* value = std::strcmp(b, "starting5.teamName") == 0 ?
            frame.starting5TeamName : frame.starting5Side;
        std::snprintf(output, capacity, "%s", value ? value : "");
        *defaultHeight = style.teamNameHeight;
        return true;
    }
    if (std::strncmp(b, "outro.raw", 9) == 0) {
        const char* indexText = b + 9;
        char* end = nullptr;
        const long index = std::strtol(indexText, &end, 10);
        if (end != indexText && *end == '\0' && index >= 0 && index < 15)
            std::snprintf(output, capacity, "%s",
                frame.outroValues[index] ? frame.outroValues[index] : "");
        else output[0] = '\0';
        *defaultHeight = style.teamNameHeight;
        return true;
    }
    struct OutroBinding { const char* name; int index; };
    static const OutroBinding outroBindings[] = {
        { "outro.homeHeading", 0 }, { "outro.awayCity", 1 },
        { "outro.awayNickname", 2 }, { "outro.awayRecord", 3 },
        { "outro.homeCity", 4 }, { "outro.homeNickname", 5 },
        { "outro.homeRecord", 6 }, { "outro.extra", 7 },
        { "outro.arena", 8 }, { "outro.location", 9 },
        { "outro.awayScore", 10 }, { "outro.homeScore", 11 },
        { "outro.awayTeamCode", 12 }, { "outro.homeTeamCode", 13 },
        { "outro.leagueCode", 14 }
    };
    for (unsigned int i = 0;
         i < sizeof(outroBindings) / sizeof(outroBindings[0]); ++i) {
        if (std::strcmp(b, outroBindings[i].name) == 0) {
            const char* value = frame.outroValues[outroBindings[i].index];
            std::snprintf(output, capacity, "%s", value ? value : "");
            *defaultHeight = style.teamNameHeight;
            return true;
        }
    }
    if (std::strncmp(b, "lineups.raw", 11) == 0) {
        const char* indexText = b + 11;
        char* end = nullptr;
        const long index = std::strtol(indexText, &end, 10);
        if (end != indexText && *end == '\0' && index >= 0 && index < 14)
            std::snprintf(output, capacity, "%s",
                frame.lineupsValues[index] ? frame.lineupsValues[index] : "");
        else output[0] = '\0';
        *defaultHeight = style.teamNameHeight;
        return true;
    }
    struct LineupsBinding { const char* name; int index; };
    static const LineupsBinding lineupsBindings[] = {
        { "lineups.awayPlayer1", 0 }, { "lineups.awayPlayer2", 1 },
        { "lineups.awayPlayer3", 2 }, { "lineups.awayPlayer4", 3 },
        { "lineups.awayPlayer5", 4 }, { "lineups.homePlayer1", 5 },
        { "lineups.homePlayer2", 6 }, { "lineups.homePlayer3", 7 },
        { "lineups.homePlayer4", 8 }, { "lineups.homePlayer5", 9 },
        { "lineups.awayTeamCode", 10 }, { "lineups.awayTeamName", 11 },
        { "lineups.homeTeamCode", 12 }, { "lineups.homeTeamName", 13 }
    };
    for (unsigned int i = 0;
         i < sizeof(lineupsBindings) / sizeof(lineupsBindings[0]); ++i) {
        if (std::strcmp(b, lineupsBindings[i].name) == 0) {
            const char* value = frame.lineupsValues[lineupsBindings[i].index];
            std::snprintf(output, capacity, "%s", value ? value : "");
            *defaultHeight = style.teamNameHeight;
            return true;
        }
    }
    if (std::strcmp(b, "player.jerseyNumber") == 0) {
        std::snprintf(output, capacity, "%s",
            frame.playerJerseyNumber ? frame.playerJerseyNumber : "");
        *defaultHeight = style.teamNameHeight;
        return true;
    }
    if (std::strcmp(b, "player.firstName") == 0 ||
        std::strcmp(b, "player.lastName") == 0 ||
        std::strcmp(b, "player.fullName") == 0) {
        if (std::strcmp(b, "player.firstName") == 0)
            std::snprintf(output, capacity, "%s",
                frame.playerFirstName ? frame.playerFirstName : "");
        else if (std::strcmp(b, "player.lastName") == 0)
            std::snprintf(output, capacity, "%s",
                frame.playerLastName ? frame.playerLastName : "");
        else
            std::snprintf(output, capacity, "%s%s%s",
                frame.playerFirstName ? frame.playerFirstName : "",
                frame.playerFirstName && *frame.playerFirstName ? " " : "",
                frame.playerLastName ? frame.playerLastName : "");
        *defaultHeight = style.teamNameHeight; return true;
    }
    if (std::strcmp(b, "stat.label1") == 0 ||
        std::strcmp(b, "stat.value1") == 0 ||
        std::strcmp(b, "stat.label2") == 0 ||
        std::strcmp(b, "stat.value2") == 0 ||
        std::strcmp(b, "stat.teamName") == 0) {
        const char* value = std::strcmp(b, "stat.label1") == 0 ? frame.statLabel1 :
            std::strcmp(b, "stat.value1") == 0 ? frame.statValue1 :
            std::strcmp(b, "stat.label2") == 0 ? frame.statLabel2 :
            std::strcmp(b, "stat.value2") == 0 ? frame.statValue2 :
            frame.statTeamName;
        std::snprintf(output, capacity, "%s", value ? value : "");
        *defaultHeight = style.teamNameHeight; return true;
    }
    if (std::strncmp(b, "stat.raw", 8) == 0) {
        const char* indexText = b + 8;
        char* end = nullptr;
        const long index = std::strtol(indexText, &end, 10);
        if (end != indexText && *end == '\0' && index >= 0 &&
            index < frame.statValueCount && index < 15) {
            const char* value = frame.statValues[index];
            std::snprintf(output, capacity, "%s", value ? value : "");
            *defaultHeight = style.teamNameHeight;
            return true;
        }
        output[0] = '\0';
        return true;
    }
    if (std::strcmp(b, "away.score") == 0) {
        std::snprintf(output, capacity, "%d", frame.awayScore);
        *defaultHeight = style.scoreHeight; return true;
    }
    if (std::strcmp(b, "home.score") == 0) {
        std::snprintf(output, capacity, "%d", frame.homeScore);
        *defaultHeight = style.scoreHeight; return true;
    }
    if (std::strcmp(b, "away.fouls") == 0 ||
        std::strcmp(b, "home.fouls") == 0) {
        std::snprintf(output, capacity, "%d",
            b[0] == 'a' ? frame.awayFouls : frame.homeFouls);
        *defaultHeight = style.foulHeight; return true;
    }
    if (std::strcmp(b, "away.timeouts") == 0 ||
        std::strcmp(b, "home.timeouts") == 0) {
        int value = b[0] == 'a' ? frame.awayTimeouts : frame.homeTimeouts;
        if (!config.timeoutCountRemaining)
            value = config.maximumTimeouts - value;
        std::snprintf(output, capacity, "%d", value);
        *defaultHeight = style.timeoutHeight; return true;
    }
    if (std::strcmp(b, "game.clock") == 0) {
        const unsigned int tenths = (frame.gameClockRaw * 10u +
            frame.clockUnitsPerSecond - 1u) / frame.clockUnitsPerSecond;
        if (tenths < 600u) std::snprintf(output, capacity, "%u.%u",
            tenths / 10u, tenths % 10u);
        else { const unsigned int seconds = frame.gameClockRaw /
            frame.clockUnitsPerSecond; std::snprintf(output, capacity,
            "%u:%02u", seconds / 60u, seconds % 60u); }
        *defaultHeight = style.clockHeight; *color = style.clockColor; return true;
    }
    if (std::strcmp(b, "game.shotClock") == 0) {
        const unsigned int seconds = (frame.shotClockRaw +
            frame.clockUnitsPerSecond - 1u) / frame.clockUnitsPerSecond;
        bool show = frame.shotClockValid && config.shotClockVisibility !=
            scoreboardconfig::ShotClockVisibility::Never;
        if (show && config.shotClockVisibility ==
            scoreboardconfig::ShotClockVisibility::UnderThreshold)
            show = seconds <= config.shotClockThreshold;
        if (!show) return false;
        std::snprintf(output, capacity, "%u", seconds);
        *defaultHeight = style.shotClockHeight;
        *color = seconds <= config.urgentShotClockThreshold ?
            config.shotClockUrgentColor : config.shotClockNormalColor;
        return true;
    }
    if (std::strcmp(b, "game.period") == 0) {
        FormatPeriod(frame.quarter, config.periodFormat, output, capacity);
        *defaultHeight = style.periodHeight; *color = style.clockColor; return true;
    }
    if (std::strcmp(b, "away.name") == 0 ||
        std::strcmp(b, "home.name") == 0) {
        std::snprintf(output, capacity, "%s",
            b[0] == 'a' ? frame.awayTeamName : frame.homeTeamName);
        return true;
    }
    const bool awayBonus = std::strcmp(b, "away.bonus") == 0;
    const bool homeBonus = std::strcmp(b, "home.bonus") == 0;
    if (awayBonus || homeBonus) {
        const int fouls = awayBonus ? frame.homeFouls : frame.awayFouls;
        if (!config.showBonus || fouls < config.bonusThreshold) return false;
        const char* value = config.doubleBonusThreshold > 0 &&
            fouls >= config.doubleBonusThreshold ? config.doubleBonusText :
            config.bonusText;
        std::snprintf(output, capacity, "%s", value);
        *defaultHeight = style.bonusHeight; return true;
    }
    std::snprintf(output, capacity, "%s", element.text);
    return true;
}

bool RenderGenericElements(IDirect3DDevice9* device,
                           const scoreboardconfig::Config& config,
                           const scoreboard::Frame& frame,
                           float originX, float originY, float scale,
                           const char* overlayName,
                           const char* overlayDirectory,
                           float overlayOpacity)
{
    if (config.elementCount <= 0) return false;
    int order[scoreboardconfig::MAX_ELEMENTS];
    for (int i = 0; i < config.elementCount; ++i) order[i] = i;
    for (int i = 1; i < config.elementCount; ++i) {
        const int value = order[i]; int j = i - 1;
        while (j >= 0 && config.elements[order[j]].z > config.elements[value].z) {
            order[j + 1] = order[j]; --j;
        }
        order[j + 1] = value;
    }

    const bool fontReady = popupfont::Begin(device, overlayName,
        overlayDirectory);
    const popupfont::Style& style = popupfont::GetStyle();
    for (int n = 0; n < config.elementCount; ++n) {
        const scoreboardconfig::Element& e = config.elements[order[n]];
        if (!e.visible) continue;
        const int opacity = static_cast<int>(e.opacity * overlayOpacity);
        const scoreboardconfig::Rect r = ToScreen(e.rect, originX, originY, scale);
        if (e.type == scoreboardconfig::ElementType::Rectangle) {
            if (e.fillType == scoreboardconfig::FillType::LinearGradient)
                DrawGradientRect(device, r.x, r.y, r.x + r.width, r.y + r.height,
                    ResolveLayerColor(e.gradientStartBinding,
                        e.gradientStartColor, frame, opacity),
                    ResolveLayerColor(e.gradientEndBinding,
                        e.gradientEndColor, frame, opacity),
                    e.gradientHorizontal);
            else DrawFilledRect(device, r.x, r.y, r.x + r.width, r.y + r.height,
                ResolveLayerColor(e.fillBinding, e.fillColor, frame, opacity));
        }
        else if (e.type == scoreboardconfig::ElementType::Image) {
            IDirect3DTexture9* texture = nullptr;
            if (std::strcmp(e.binding, "away.logo") == 0) texture = frame.awayLogo;
            else if (std::strcmp(e.binding, "home.logo") == 0) texture = frame.homeLogo;
            else if (std::strcmp(e.binding, "violation.teamLogo") == 0)
                texture = frame.violationTeamLogo;
            else if (std::strcmp(e.binding, "stat.teamLogo") == 0)
                texture = frame.statTeamLogo;
            else if (std::strcmp(e.binding, "intro.awayLogo") == 0)
                texture = frame.awayLogo;
            else if (std::strcmp(e.binding, "intro.homeLogo") == 0)
                texture = frame.homeLogo;
            else if (std::strcmp(e.binding, "starting5.teamLogo") == 0)
                texture = frame.starting5TeamLogo;
            else if (std::strcmp(e.binding, "starting5.player1Portrait") == 0)
                texture = frame.starting5PlayerPortraits[0];
            else if (std::strcmp(e.binding, "starting5.player2Portrait") == 0)
                texture = frame.starting5PlayerPortraits[1];
            else if (std::strcmp(e.binding, "starting5.player3Portrait") == 0)
                texture = frame.starting5PlayerPortraits[2];
            else if (std::strcmp(e.binding, "starting5.player4Portrait") == 0)
                texture = frame.starting5PlayerPortraits[3];
            else if (std::strcmp(e.binding, "starting5.player5Portrait") == 0)
                texture = frame.starting5PlayerPortraits[4];
            else if (std::strcmp(e.binding, "outro.awayLogo") == 0)
                texture = frame.awayLogo;
            else if (std::strcmp(e.binding, "outro.homeLogo") == 0)
                texture = frame.homeLogo;
            else if (std::strcmp(e.binding, "lineups.awayLogo") == 0)
                texture = frame.awayLogo;
            else if (std::strcmp(e.binding, "lineups.homeLogo") == 0)
                texture = frame.homeLogo;
            else if (std::strcmp(e.binding, "player.portrait") == 0)
                texture = frame.playerPortrait;
            else if (e.image[0]) texture = popup::GetOverlayTexture(device,
                overlayName, overlayDirectory, e.image);
            const D3DCOLOR tint = e.tintEnabled ? ResolveLayerColor(
                e.tintBinding, e.tintColor, frame, opacity) :
                D3DCOLOR_ARGB(opacity < 0 ? 0 : opacity > 255 ? 255 : opacity,
                    255, 255, 255);
            if (e.imageFit == scoreboardconfig::ImageFit::Stretch)
                DrawTextureStretched(device, texture, r.x, r.y,
                    r.x + r.width, r.y + r.height, tint, e.tintEnabled);
            else
                DrawTexture(device, texture, r.x, r.y,
                    r.x + r.width, r.y + r.height, tint, e.tintEnabled);
        }
        else if (e.type == scoreboardconfig::ElementType::Text && fontReady) {
            if (!popupfont::SelectFont(device, overlayName, e.font,
                    overlayDirectory)) continue;
            char text[512]; float height; D3DCOLOR color;
            if (!ResolveLayerText(e, config, frame, text, sizeof(text),
                    &height, style, &color)) continue;
            if (e.textColor != D3DCOLOR_XRGB(255, 255, 255) || !e.binding[0])
                color = e.textColor;
            if (e.fontHeight > 0.0f) height = e.fontHeight;
            const int alignment = e.alignment == scoreboardconfig::TextAlignment::Left ?
                -1 : e.alignment == scoreboardconfig::TextAlignment::Right ? 1 : 0;
            const bool fit =
                e.overflow == scoreboardconfig::TextOverflow::Fit;
            if (e.shadowEnabled && e.shadowAlpha > 0) {
                scoreboardconfig::Rect shadowRect = r;
                shadowRect.x += e.shadowOffsetX * scale;
                shadowRect.y += e.shadowOffsetY * scale;
                const int shadowOpacity = opacity * e.shadowAlpha / 255;
                DrawBoundText(device, text, shadowRect, height * scale,
                    WithOpacity(e.shadowColor, shadowOpacity), alignment, fit,
                    e.textTransform, e.smallCapsScale);
            }
            if (e.strokeEnabled && e.strokeWidth > 0.0f) {
                const int radius = static_cast<int>(
                    std::ceil(e.strokeWidth * scale));
                const float radiusSquared =
                    e.strokeWidth * scale * e.strokeWidth * scale + 0.25f;
                for (int y = -radius; y <= radius; ++y) {
                    for (int x = -radius; x <= radius; ++x) {
                        if ((!x && !y) ||
                            static_cast<float>(x * x + y * y) >
                                radiusSquared) continue;
                        scoreboardconfig::Rect strokeRect = r;
                        strokeRect.x += static_cast<float>(x);
                        strokeRect.y += static_cast<float>(y);
                        DrawBoundText(device, text, strokeRect, height * scale,
                            WithOpacity(e.strokeColor, opacity), alignment, fit,
                            e.textTransform, e.smallCapsScale);
                    }
                }
            }
            DrawBoundText(device, text, r, height * scale,
                WithOpacity(color, opacity), alignment, fit,
                e.textTransform, e.smallCapsScale);
        }
        else if (e.type == scoreboardconfig::ElementType::Indicator && fontReady) {
            if (!popupfont::SelectFont(device, overlayName, e.font,
                    overlayDirectory)) continue;
            const bool foul = std::strstr(e.binding, "fouls") != nullptr;
            const bool away = std::strncmp(e.binding, "away.", 5) == 0;
            int value = foul ? (away ? frame.awayFouls : frame.homeFouls) :
                (away ? frame.awayTimeouts : frame.homeTimeouts);
            if (!foul && !config.timeoutCountRemaining)
                value = config.maximumTimeouts - value;
            const scoreboardconfig::IndicatorMode mode = foul ?
                config.foulMode : config.timeoutMode;
            IDirect3DTexture9* image = mode == scoreboardconfig::IndicatorMode::Images ?
                popup::GetThemeTexture(device, foul ? config.foulImage :
                    config.timeoutImage) : nullptr;
            DrawIndicator(device, mode, r, value,
                foul ? config.maximumTeamFouls : config.maximumTimeouts,
                foul ? "F" : "TO", image, WithOpacity(style.scoreColor, opacity),
                (e.fontHeight > 0.0f ? e.fontHeight :
                    (foul ? style.foulHeight : style.timeoutHeight)) * scale);
        }
    }
    return true;
}

void DrawIndicator(IDirect3DDevice9* device,
                   scoreboardconfig::IndicatorMode mode,
                   const scoreboardconfig::Rect& rectangle,
                   int value, int maximum, const char* label,
                   IDirect3DTexture9* image, D3DCOLOR color,
                   float textHeight)
{
    if (mode == scoreboardconfig::IndicatorMode::None || value < 0) return;
    if (value > maximum && maximum > 0) value = maximum;
    if (mode == scoreboardconfig::IndicatorMode::Number ||
        mode == scoreboardconfig::IndicatorMode::Text) {
        char text[32];
        if (mode == scoreboardconfig::IndicatorMode::Text)
            std::snprintf(text, sizeof(text), "%s %d", label, value);
        else
            std::snprintf(text, sizeof(text), "%d", value);
        DrawBoundText(device, text, rectangle,
            textHeight, color, 0);
        return;
    }
    if (maximum <= 0) return;
    const float spacing = 2.0f;
    const float itemWidth =
        (rectangle.width - spacing * (maximum - 1)) / maximum;
    for (int i = 0; i < maximum; ++i) {
        const float left = rectangle.x + i * (itemWidth + spacing);
        const float dot = itemWidth < rectangle.height ?
            itemWidth : rectangle.height;
        if (i >= value) {
            if (mode == scoreboardconfig::IndicatorMode::Dots)
                DrawFilledCircle(device, left + dot * 0.5f,
                    rectangle.y + rectangle.height * 0.5f,
                    dot * 0.5f, D3DCOLOR_ARGB(85, 255, 255, 255));
            else
                DrawFilledRect(device, left, rectangle.y,
                    left + itemWidth, rectangle.y + rectangle.height,
                    D3DCOLOR_ARGB(85, 255, 255, 255));
            continue;
        }
        if (mode == scoreboardconfig::IndicatorMode::Images && image)
            DrawTexture(device, image, left, rectangle.y,
                left + itemWidth, rectangle.y + rectangle.height);
        else if (mode == scoreboardconfig::IndicatorMode::Dots) {
            DrawFilledCircle(device, left + dot * 0.5f,
                rectangle.y + rectangle.height * 0.5f,
                dot * 0.5f, color);
        }
        else
            DrawFilledRect(device, left, rectangle.y,
                left + itemWidth, rectangle.y + rectangle.height, color);
    }
}

} // namespace

void Render(IDirect3DDevice9* device, const Frame& frame,
            const char* overlayName)
{
    if (!device || !overlayName || !*overlayName || !frame.clockUnitsPerSecond ||
        frame.homeScore < 0 || frame.awayScore < 0)
        return;

    D3DVIEWPORT9 viewport = {};
    if (FAILED(device->GetViewport(&viewport))) return;

    IDirect3DStateBlock9* stateBlock = nullptr;
    if (SUCCEEDED(device->CreateStateBlock(D3DSBT_ALL, &stateBlock)))
        stateBlock->Capture();

    device->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    device->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    device->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    device->SetRenderState(D3DRS_ZENABLE, FALSE);
    device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    device->SetRenderState(D3DRS_LIGHTING, FALSE);
    device->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
    device->SetVertexShader(nullptr);
    device->SetPixelShader(nullptr);
    device->SetTexture(0, nullptr);
    device->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
    device->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_DIFFUSE);
    device->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
    device->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
    // NBA Live may leave sampler 0 configured for point filtering. That is
    // especially visible when a reference-resolution scoreboard is reduced
    // to 640x480: logos become grainy and the GDI glyph atlas stair-steps.
    // The state block restores the game's original sampler state afterward.
    device->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
    device->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
    device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

    const scoreboardconfig::Config& config = scoreboardconfig::Get();
    float scale = 1.0f;
    if (config.scaleMode == scoreboardconfig::ScaleMode::Uniform) {
        const float scaleX = static_cast<float>(viewport.Width) /
            config.referenceWidth;
        const float scaleY = static_cast<float>(viewport.Height) /
            config.referenceHeight;
        scale = scaleX < scaleY ? scaleX : scaleY;
    }
    const float width = config.width * scale;
    const float height = config.height * scale;
    const float left = (static_cast<float>(viewport.Width) - width) * 0.5f +
        config.offsetX * (config.scaleMode ==
            scoreboardconfig::ScaleMode::Uniform ? scale : 1.0f);
    const float top = config.offsetY * (config.scaleMode ==
        scoreboardconfig::ScaleMode::Uniform ? scale : 1.0f);
    const float right = left + width;
    const float bottom = top + height;

    // New themes render entirely from their ordered elements[] collection.
    // Themes without elements[] continue through the legacy path below.
    if (RenderGenericElements(device, config, frame, left, top, scale,
            overlayName, "scoreboard", 1.0f)) {
        if (stateBlock) {
            stateBlock->Apply();
            stateBlock->Release();
        }
        return;
    }

    const scoreboardconfig::Rect awayPanel =
        ToScreen(config.awayPanel, left, top, scale);
    const scoreboardconfig::Rect homePanel =
        ToScreen(config.homePanel, left, top, scale);
    int backgroundAlpha = config.backgroundAlpha;
    if (backgroundAlpha < 0) backgroundAlpha = 0;
    if (backgroundAlpha > 255) backgroundAlpha = 255;
    const D3DCOLOR backgroundColor =
        (static_cast<D3DCOLOR>(backgroundAlpha) << 24) |
        (config.backgroundColor & 0x00FFFFFFu);
    DrawFilledRect(device, left, top, right, bottom, backgroundColor);
    if (config.showBackgroundImage && config.backgroundImage[0]) {
        IDirect3DTexture9* backgroundImage =
            popup::GetThemeTexture(device, config.backgroundImage);
        int imageAlpha = config.backgroundImageAlpha;
        if (imageAlpha < 0) imageAlpha = 0;
        if (imageAlpha > 255) imageAlpha = 255;
        DrawTextureStretched(device, backgroundImage,
            left, top, right, bottom,
            D3DCOLOR_ARGB(imageAlpha, 255, 255, 255));
    }
    DrawFilledRect(device, awayPanel.x, awayPanel.y,
        awayPanel.x + awayPanel.width, awayPanel.y + awayPanel.height,
        frame.awayColor);
    DrawFilledRect(device, homePanel.x, homePanel.y,
        homePanel.x + homePanel.width, homePanel.y + homePanel.height,
        frame.homeColor);
    if (config.showAccent && config.accentHeight > 0.0f) {
        const float accentHeight = config.accentHeight * scale;
        DrawFilledRect(device, awayPanel.x,
            awayPanel.y + awayPanel.height - accentHeight,
            awayPanel.x + awayPanel.width,
            awayPanel.y + awayPanel.height, frame.awaySecondaryColor);
        DrawFilledRect(device, homePanel.x,
            homePanel.y + homePanel.height - accentHeight,
            homePanel.x + homePanel.width,
            homePanel.y + homePanel.height, frame.homeSecondaryColor);
    }

    scoreboardconfig::Rect awayLogo =
        ToScreen(config.awayLogo, left, top, scale);
    if (config.showAwayLogo)
        DrawTexture(device, frame.awayLogo,
            awayLogo.x, awayLogo.y,
            awayLogo.x + awayLogo.width,
            awayLogo.y + awayLogo.height);
    scoreboardconfig::Rect homeLogo =
        ToScreen(config.homeLogo, left, top, scale);
    if (config.showHomeLogo)
        DrawTexture(device, frame.homeLogo, homeLogo.x, homeLogo.y,
            homeLogo.x + homeLogo.width, homeLogo.y + homeLogo.height);

    const unsigned int shotSeconds =
        (frame.shotClockRaw + frame.clockUnitsPerSecond - 1u) /
        frame.clockUnitsPerSecond;
    const D3DCOLOR white = D3DCOLOR_XRGB(255, 255, 255);
    if (popupfont::Begin(device, overlayName)) {
        const popupfont::Style& style = popupfont::GetStyle();
        char awayScore[16];
        char homeScore[16];
        char clock[16];
        char shotClock[16];
        std::sprintf(awayScore, "%d", frame.awayScore);
        std::sprintf(homeScore, "%d", frame.homeScore);
        const unsigned int totalTenths =
            (frame.gameClockRaw * 10u + frame.clockUnitsPerSecond - 1u) /
            frame.clockUnitsPerSecond;
        if (totalTenths < 600u)
            std::sprintf(clock, "%u.%u", totalTenths / 10u,
                totalTenths % 10u);
        else {
            const unsigned int totalSeconds =
                frame.gameClockRaw / frame.clockUnitsPerSecond;
            std::sprintf(clock, "%u:%02u", totalSeconds / 60u,
                totalSeconds % 60u);
        }
        std::sprintf(shotClock, "%u", shotSeconds);
        DrawBoundText(device, awayScore,
            ToScreen(config.awayScore, left, top, scale),
            style.scoreHeight * scale, style.scoreColor, 1);
        DrawBoundText(device, homeScore,
            ToScreen(config.homeScore, left, top, scale),
            style.scoreHeight * scale, style.scoreColor, 1);
        DrawBoundText(device, clock,
            ToScreen(config.gameClock, left, top, scale),
            style.clockHeight * scale, style.clockColor, 0);

        bool showShotClock = frame.shotClockValid &&
            config.shotClockVisibility !=
                scoreboardconfig::ShotClockVisibility::Never;
        if (showShotClock && config.shotClockVisibility ==
                scoreboardconfig::ShotClockVisibility::UnderThreshold)
            showShotClock = shotSeconds <= config.shotClockThreshold;
        if (showShotClock) {
            D3DCOLOR shotColor = shotSeconds <=
                config.urgentShotClockThreshold ?
                config.shotClockUrgentColor : config.shotClockNormalColor;
            DrawBoundText(device, shotClock,
                ToScreen(config.shotClock, left, top, scale),
                style.shotClockHeight * scale, shotColor, 1);
        }

        char period[32];
        FormatPeriod(frame.quarter, config.periodFormat,
            period, sizeof(period));
        DrawBoundText(device, period,
            ToScreen(config.period, left, top, scale),
            style.periodHeight * scale, style.clockColor, 0);
        if (config.showTeamNames) {
            DrawBoundText(device, frame.awayTeamName,
                ToScreen(config.awayName, left, top, scale),
                style.teamNameHeight * scale, style.scoreColor, 0);
            DrawBoundText(device, frame.homeTeamName,
                ToScreen(config.homeName, left, top, scale),
                style.teamNameHeight * scale, style.scoreColor, 0);
        }

        int awayTimeouts = frame.awayTimeouts;
        int homeTimeouts = frame.homeTimeouts;
        if (!config.timeoutCountRemaining) {
            awayTimeouts = config.maximumTimeouts - awayTimeouts;
            homeTimeouts = config.maximumTimeouts - homeTimeouts;
        }
        IDirect3DTexture9* foulImage =
            config.foulMode == scoreboardconfig::IndicatorMode::Images ?
            popup::GetThemeTexture(device, config.foulImage) : nullptr;
        IDirect3DTexture9* timeoutImage =
            config.timeoutMode == scoreboardconfig::IndicatorMode::Images ?
            popup::GetThemeTexture(device, config.timeoutImage) : nullptr;
        DrawIndicator(device, config.foulMode,
            ToScreen(config.awayFouls, left, top, scale),
            frame.awayFouls, config.maximumTeamFouls,
            "F", foulImage, style.scoreColor, style.foulHeight * scale);
        DrawIndicator(device, config.foulMode,
            ToScreen(config.homeFouls, left, top, scale),
            frame.homeFouls, config.maximumTeamFouls,
            "F", foulImage, style.scoreColor, style.foulHeight * scale);
        DrawIndicator(device, config.timeoutMode,
            ToScreen(config.awayTimeouts, left, top, scale),
            awayTimeouts, config.maximumTimeouts,
            "TO", timeoutImage, style.scoreColor,
            style.timeoutHeight * scale);
        DrawIndicator(device, config.timeoutMode,
            ToScreen(config.homeTimeouts, left, top, scale),
            homeTimeouts, config.maximumTimeouts,
            "TO", timeoutImage, style.scoreColor,
            style.timeoutHeight * scale);

        if (config.showBonus && frame.homeFouls >= config.bonusThreshold) {
            const char* bonus = config.doubleBonusThreshold > 0 &&
                frame.homeFouls >= config.doubleBonusThreshold ?
                config.doubleBonusText : config.bonusText;
            DrawBoundText(device, bonus,
                ToScreen(config.awayBonus, left, top, scale),
                style.bonusHeight * scale, style.scoreColor, 0);
        }
        if (config.showBonus && frame.awayFouls >= config.bonusThreshold) {
            const char* bonus = config.doubleBonusThreshold > 0 &&
                frame.awayFouls >= config.doubleBonusThreshold ?
                config.doubleBonusText : config.bonusText;
            DrawBoundText(device, bonus,
                ToScreen(config.homeBonus, left, top, scale),
                style.bonusHeight * scale, style.scoreColor, 0);
        }
    }
    else {
        DrawInteger(device, static_cast<unsigned int>(frame.awayScore),
            left + 236.0f * scale, top + 17.0f * scale,
            16.0f, 34.0f, 5.0f, white);
        DrawInteger(device, static_cast<unsigned int>(frame.homeScore),
            left + 422.0f * scale, top + 17.0f * scale,
            16.0f, 34.0f, 5.0f, white);
        DrawGameClock(device, frame.gameClockRaw,
            frame.clockUnitsPerSecond,
            left + 310.0f * scale, top + 10.0f * scale, white);
        if (frame.shotClockValid)
            DrawInteger(device, shotSeconds, left + 364.0f * scale,
                top + 43.0f, 8.0f, 17.0f, 2.0f,
                D3DCOLOR_XRGB(255, 210, 64));
    }

    if (stateBlock) {
        stateBlock->Apply();
        stateBlock->Release();
    }
}

void RenderViolation(IDirect3DDevice9* device, const Frame& frame,
    const char* overlayName, float animationOffsetX,
    float animationOffsetY, float animationOpacity)
{
    if (!device || !overlayName || !*overlayName ||
        !frame.violationTitle || !*frame.violationTitle ||
        animationOpacity <= 0.0f) return;
    D3DVIEWPORT9 viewport = {};
    if (FAILED(device->GetViewport(&viewport))) return;
    IDirect3DStateBlock9* stateBlock = nullptr;
    if (SUCCEEDED(device->CreateStateBlock(D3DSBT_ALL, &stateBlock)))
        stateBlock->Capture();
    device->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    device->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    device->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    device->SetRenderState(D3DRS_ZENABLE, FALSE);
    device->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
    device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    device->SetVertexShader(nullptr); device->SetPixelShader(nullptr);
    device->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
    device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

    const scoreboardconfig::Config& config = scoreboardconfig::GetViolation();
    float scale = 1.0f;
    if (config.scaleMode == scoreboardconfig::ScaleMode::Uniform) {
        const float sx = static_cast<float>(viewport.Width) / config.referenceWidth;
        const float sy = static_cast<float>(viewport.Height) / config.referenceHeight;
        scale = sx < sy ? sx : sy;
    }
    const float offsetScale = config.scaleMode ==
        scoreboardconfig::ScaleMode::Uniform ? scale : 1.0f;
    const float left = (static_cast<float>(viewport.Width) -
        config.width * scale) * 0.5f +
        (config.offsetX + animationOffsetX) * offsetScale;
    const float top = (config.offsetY + animationOffsetY) * offsetScale;
    RenderGenericElements(device, config, frame, left, top, scale,
        overlayName, "violation", animationOpacity);
    if (stateBlock) { stateBlock->Apply(); stateBlock->Release(); }
}

void RenderPlayCall(IDirect3DDevice9* device, const Frame& frame,
    const char* overlayName, float animationOffsetX,
    float animationOffsetY, float animationOpacity)
{
    if (!device || !overlayName || !*overlayName ||
        !frame.playCallName || !*frame.playCallName ||
        animationOpacity <= 0.0f) return;
    D3DVIEWPORT9 viewport = {};
    if (FAILED(device->GetViewport(&viewport))) return;
    IDirect3DStateBlock9* stateBlock = nullptr;
    if (SUCCEEDED(device->CreateStateBlock(D3DSBT_ALL, &stateBlock)))
        stateBlock->Capture();
    device->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    device->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    device->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    device->SetRenderState(D3DRS_ZENABLE, FALSE);
    device->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
    device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    device->SetVertexShader(nullptr); device->SetPixelShader(nullptr);
    device->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
    device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

    const scoreboardconfig::Config& config = scoreboardconfig::GetPlayCall();
    float scale = 1.0f;
    if (config.scaleMode == scoreboardconfig::ScaleMode::Uniform) {
        const float sx = static_cast<float>(viewport.Width) / config.referenceWidth;
        const float sy = static_cast<float>(viewport.Height) / config.referenceHeight;
        scale = sx < sy ? sx : sy;
    }
    const float offsetScale = config.scaleMode ==
        scoreboardconfig::ScaleMode::Uniform ? scale : 1.0f;
    const float left = (static_cast<float>(viewport.Width) -
        config.width * scale) * 0.5f +
        (config.offsetX + animationOffsetX) * offsetScale;
    const float top = (config.offsetY + animationOffsetY) * offsetScale;
    RenderGenericElements(device, config, frame, left, top, scale,
        overlayName, "playcall", animationOpacity);
    if (stateBlock) { stateBlock->Apply(); stateBlock->Release(); }
}

void RenderIntro(IDirect3DDevice9* device, const Frame& frame,
    const char* overlayName, float animationOffsetX,
    float animationOffsetY, float animationOpacity)
{
    if (!device || !overlayName || !*overlayName ||
        !frame.introValues[0] || !*frame.introValues[0] ||
        animationOpacity <= 0.0f) return;
    D3DVIEWPORT9 viewport = {};
    if (FAILED(device->GetViewport(&viewport))) return;
    IDirect3DStateBlock9* stateBlock = nullptr;
    if (SUCCEEDED(device->CreateStateBlock(D3DSBT_ALL, &stateBlock)))
        stateBlock->Capture();
    device->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    device->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    device->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    device->SetRenderState(D3DRS_ZENABLE, FALSE);
    device->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
    device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    device->SetVertexShader(nullptr); device->SetPixelShader(nullptr);
    device->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
    device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

    const scoreboardconfig::Config& config = scoreboardconfig::GetIntro();
    float scale = 1.0f;
    if (config.scaleMode == scoreboardconfig::ScaleMode::Uniform) {
        const float sx = static_cast<float>(viewport.Width) / config.referenceWidth;
        const float sy = static_cast<float>(viewport.Height) / config.referenceHeight;
        scale = sx < sy ? sx : sy;
    }
    const float offsetScale = config.scaleMode ==
        scoreboardconfig::ScaleMode::Uniform ? scale : 1.0f;
    const float left = (static_cast<float>(viewport.Width) -
        config.width * scale) * 0.5f +
        (config.offsetX + animationOffsetX) * offsetScale;
    const float top = (config.offsetY + animationOffsetY) * offsetScale;
    RenderGenericElements(device, config, frame, left, top, scale,
        overlayName, "intro", animationOpacity);
    if (stateBlock) { stateBlock->Apply(); stateBlock->Release(); }
}

void RenderStarting5(IDirect3DDevice9* device, const Frame& frame,
    const char* overlayName, float animationOffsetX,
    float animationOffsetY, float animationOpacity)
{
    if (!device || !overlayName || !*overlayName ||
        !frame.starting5Values[5] || !*frame.starting5Values[5] ||
        animationOpacity <= 0.0f) return;
    D3DVIEWPORT9 viewport = {};
    if (FAILED(device->GetViewport(&viewport))) return;
    IDirect3DStateBlock9* stateBlock = nullptr;
    if (SUCCEEDED(device->CreateStateBlock(D3DSBT_ALL, &stateBlock)))
        stateBlock->Capture();
    device->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    device->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    device->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    device->SetRenderState(D3DRS_ZENABLE, FALSE);
    device->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
    device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    device->SetVertexShader(nullptr); device->SetPixelShader(nullptr);
    device->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
    device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
    const scoreboardconfig::Config& config = scoreboardconfig::GetStarting5();
    float scale = 1.0f;
    if (config.scaleMode == scoreboardconfig::ScaleMode::Uniform) {
        const float sx = static_cast<float>(viewport.Width) / config.referenceWidth;
        const float sy = static_cast<float>(viewport.Height) / config.referenceHeight;
        scale = sx < sy ? sx : sy;
    }
    const float offsetScale = config.scaleMode ==
        scoreboardconfig::ScaleMode::Uniform ? scale : 1.0f;
    const float left = (static_cast<float>(viewport.Width) -
        config.width * scale) * 0.5f +
        (config.offsetX + animationOffsetX) * offsetScale;
    const float top = (config.offsetY + animationOffsetY) * offsetScale;
    RenderGenericElements(device, config, frame, left, top, scale,
        overlayName, "starting5", animationOpacity);
    if (stateBlock) { stateBlock->Apply(); stateBlock->Release(); }
}

void RenderOutro(IDirect3DDevice9* device, const Frame& frame,
    const char* overlayName, float animationOffsetX,
    float animationOffsetY, float animationOpacity)
{
    if (!device || !overlayName || !*overlayName ||
        !frame.outroValues[0] || !*frame.outroValues[0] ||
        animationOpacity <= 0.0f) return;
    D3DVIEWPORT9 viewport = {};
    if (FAILED(device->GetViewport(&viewport))) return;
    IDirect3DStateBlock9* stateBlock = nullptr;
    if (SUCCEEDED(device->CreateStateBlock(D3DSBT_ALL, &stateBlock)))
        stateBlock->Capture();
    device->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    device->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    device->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    device->SetRenderState(D3DRS_ZENABLE, FALSE);
    device->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
    device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    device->SetVertexShader(nullptr); device->SetPixelShader(nullptr);
    device->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
    device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
    const scoreboardconfig::Config& config = scoreboardconfig::GetOutro();
    float scale = 1.0f;
    if (config.scaleMode == scoreboardconfig::ScaleMode::Uniform) {
        const float sx = static_cast<float>(viewport.Width) / config.referenceWidth;
        const float sy = static_cast<float>(viewport.Height) / config.referenceHeight;
        scale = sx < sy ? sx : sy;
    }
    const float offsetScale = config.scaleMode ==
        scoreboardconfig::ScaleMode::Uniform ? scale : 1.0f;
    const float left = (static_cast<float>(viewport.Width) -
        config.width * scale) * 0.5f +
        (config.offsetX + animationOffsetX) * offsetScale;
    const float top = (config.offsetY + animationOffsetY) * offsetScale;
    RenderGenericElements(device, config, frame, left, top, scale,
        overlayName, "outro", animationOpacity);
    if (stateBlock) { stateBlock->Apply(); stateBlock->Release(); }
}

void RenderLineups(IDirect3DDevice9* device, const Frame& frame,
    const char* overlayName, float animationOffsetX,
    float animationOffsetY, float animationOpacity)
{
    if (!device || !overlayName || !*overlayName ||
        !frame.lineupsValues[0] || !*frame.lineupsValues[0] ||
        animationOpacity <= 0.0f) return;
    D3DVIEWPORT9 viewport = {};
    if (FAILED(device->GetViewport(&viewport))) return;
    IDirect3DStateBlock9* stateBlock = nullptr;
    if (SUCCEEDED(device->CreateStateBlock(D3DSBT_ALL, &stateBlock)))
        stateBlock->Capture();
    device->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    device->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    device->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    device->SetRenderState(D3DRS_ZENABLE, FALSE);
    device->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
    device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    device->SetVertexShader(nullptr); device->SetPixelShader(nullptr);
    device->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
    device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
    const scoreboardconfig::Config& config = scoreboardconfig::GetLineups();
    float scale = 1.0f;
    if (config.scaleMode == scoreboardconfig::ScaleMode::Uniform) {
        const float sx = static_cast<float>(viewport.Width) /
            config.referenceWidth;
        const float sy = static_cast<float>(viewport.Height) /
            config.referenceHeight;
        scale = sx < sy ? sx : sy;
    }
    const float offsetScale = config.scaleMode ==
        scoreboardconfig::ScaleMode::Uniform ? scale : 1.0f;
    const float left = (static_cast<float>(viewport.Width) -
        config.width * scale) * 0.5f +
        (config.offsetX + animationOffsetX) * offsetScale;
    const float top = (config.offsetY + animationOffsetY) * offsetScale;
    RenderGenericElements(device, config, frame, left, top, scale,
        overlayName, "lineups", animationOpacity);
    if (stateBlock) { stateBlock->Apply(); stateBlock->Release(); }
}

void RenderPlayerFoul(IDirect3DDevice9* device, const Frame& frame,
    const char* overlayName, float animationOffsetX,
    float animationOffsetY, float animationOpacity)
{
    if (!device || !overlayName || !*overlayName ||
        !frame.playerLastName || !*frame.playerLastName ||
        animationOpacity <= 0.0f) return;
    D3DVIEWPORT9 viewport = {};
    if (FAILED(device->GetViewport(&viewport))) return;
    IDirect3DStateBlock9* stateBlock = nullptr;
    if (SUCCEEDED(device->CreateStateBlock(D3DSBT_ALL, &stateBlock)))
        stateBlock->Capture();
    device->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    device->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    device->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    device->SetRenderState(D3DRS_ZENABLE, FALSE);
    device->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
    device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    device->SetVertexShader(nullptr); device->SetPixelShader(nullptr);
    device->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
    device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

    const scoreboardconfig::Config& config = scoreboardconfig::GetPlayerFoul();
    float scale = 1.0f;
    if (config.scaleMode == scoreboardconfig::ScaleMode::Uniform) {
        const float sx = static_cast<float>(viewport.Width) / config.referenceWidth;
        const float sy = static_cast<float>(viewport.Height) / config.referenceHeight;
        scale = sx < sy ? sx : sy;
    }
    const float offsetScale = config.scaleMode ==
        scoreboardconfig::ScaleMode::Uniform ? scale : 1.0f;
    const float left = (static_cast<float>(viewport.Width) -
        config.width * scale) * 0.5f +
        (config.offsetX + animationOffsetX) * offsetScale;
    const float top = (config.offsetY + animationOffsetY) * offsetScale;
    RenderGenericElements(device, config, frame, left, top, scale,
        overlayName, "stats", animationOpacity);
    if (stateBlock) { stateBlock->Apply(); stateBlock->Release(); }
}

void RenderStat(IDirect3DDevice9* device, const Frame& frame,
    const char* overlayName, float animationOffsetX,
    float animationOffsetY, float animationOpacity)
{
    if (!device || !overlayName || !*overlayName ||
        frame.statValueCount <= 0 || animationOpacity <= 0.0f)
        return;
    D3DVIEWPORT9 viewport = {};
    if (FAILED(device->GetViewport(&viewport))) return;
    IDirect3DStateBlock9* stateBlock = nullptr;
    if (SUCCEEDED(device->CreateStateBlock(D3DSBT_ALL, &stateBlock)))
        stateBlock->Capture();
    device->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    device->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    device->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    device->SetRenderState(D3DRS_ZENABLE, FALSE);
    device->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
    device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    device->SetVertexShader(nullptr); device->SetPixelShader(nullptr);
    device->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
    device->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
    device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

    const scoreboardconfig::Config& config = scoreboardconfig::GetStat();
    float scale = 1.0f;
    if (config.scaleMode == scoreboardconfig::ScaleMode::Uniform) {
        const float sx = static_cast<float>(viewport.Width) / config.referenceWidth;
        const float sy = static_cast<float>(viewport.Height) / config.referenceHeight;
        scale = sx < sy ? sx : sy;
    }
    const float offsetScale = config.scaleMode ==
        scoreboardconfig::ScaleMode::Uniform ? scale : 1.0f;
    const float left = (static_cast<float>(viewport.Width) -
        config.width * scale) * 0.5f +
        (config.offsetX + animationOffsetX) * offsetScale;
    const float top = (config.offsetY + animationOffsetY) * offsetScale;
    RenderGenericElements(device, config, frame, left, top, scale,
        overlayName, "stats", animationOpacity);
    if (stateBlock) { stateBlock->Apply(); stateBlock->Release(); }
}

} // namespace scoreboard

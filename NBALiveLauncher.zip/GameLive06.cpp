#include "plugin-std.h"
#include "Resolutions.h"
#include "AdjustWSUI.h"

using namespace plugin;

const unsigned int RES_X = GetPrivateProfileIntW(L"DISPLAY", L"RES_X", 640, L".\\main.ini");
const unsigned int RES_Y = GetPrivateProfileIntW(L"DISPLAY", L"RES_Y", 480, L".\\main.ini");
const unsigned int INTRO = GetPrivateProfileIntW(L"BOOTUP", L"INTRO", 1, L".\\main.ini");
const float ASPECT_RATIO = static_cast<float>(RES_X) / static_cast<float>(RES_Y);

namespace live06 {
    
    // An array of resolutions
    ResolutionID ids[] = {
        { 640,  480, 32, 0 }, // 640x480x16
        { 800,  600, 32, 1 }, // 640x480x32
        { 1024,  768, 32, 2 }, // 800x600x16
        { 1280,  720, 32, 3 }, // 800x600x32
        { 1280, 1024, 32, 4 },
        { 1366,  768, 32, 5 },
        { 1440,  900, 32, 6 },
        { 1600,  900, 32, 7 },
        { 1920, 1080, 32, 8 },
        { 2560, 1440, 32, 9 },
    };

    // Function modified to set aspect ratio based on height and width
// NBA Live 06
// Correct widescreen projection:
// - preserves vertical FOV
// - uses actual viewport aspect ratio
// - preserves original near/far planes
    DWORD* METHOD SetPerspectiveProjection06(
        float* _this, DUMMY_ARG,
        DWORD* a2,
        float fovY,
        float aspectRatio,
        float nearClip,
        float farClip)
    {
        const float w =
            static_cast<float>(*reinterpret_cast<unsigned int*>(_this + 2));

        const float h =
            static_cast<float>(*reinterpret_cast<unsigned int*>(_this + 3));

        if (h > 0.0f)
            aspectRatio = w / h;

        _this[15] = 0.0f;        // mGuardBandScale
        _this[6] = fovY;        // mFrustum.mFov
        _this[7] = aspectRatio; // mFrustum.mAspect
        _this[8] = nearClip;    // mFrustum.mNearPlane
        _this[9] = farClip;     // mFrustum.mFarPlane

        memcpy(_this + 36, (void*)0xBE9DC0, 0x40u);

        const double fovR =
            1.0 / tan(static_cast<double>(fovY) * 0.0087266462);

        _this[47] = -1.0f; // mProjectionMatrix.m44[2][3]

        _this[36] = static_cast<float>(
            0.5 * static_cast<double>(w) /
            static_cast<double>(aspectRatio) *
            fovR
            );

        _this[41] = static_cast<float>(
            -(static_cast<double>(h) * 0.5 * fovR)
            );

        _this[44] = static_cast<float>(
            static_cast<double>(w) * -0.5 -
            static_cast<double>(*reinterpret_cast<int*>(_this))
            );

        _this[45] = static_cast<float>(
            static_cast<double>(h) * -0.5 -
            static_cast<double>(*reinterpret_cast<int*>(_this + 1))
            );

        const double dist =
            static_cast<double>(nearClip) -
            static_cast<double>(farClip);

        _this[46] = static_cast<float>(
            static_cast<double>(nearClip) / dist - 1.0
            );

        _this[50] = static_cast<float>(
            static_cast<double>(nearClip) *
            static_cast<double>(farClip) / dist
            );

        CallMethod<0x702DF1>(_this, a2);

        return a2;
    }


    // NBA Live 06
    // Correct widescreen conservative conical-frustum culling.
    //
    // Original StaticFastCull is based on a circular cone. Widescreen
    // exposes a wider horizontal FOV, so widen the cone itself rather
    // than modifying near/far clipping distances.
    int METHOD SetTestInConicalFrustum06(
        float* _this, DUMMY_ARG,
        float* a2,
        float radius,
        bool cameraclip)
    {
        float v8 = a2[0] - _this[4];
        float v9 = a2[1] - _this[5];
        float v10 = a2[2] - _this[6];

        float v7 = v10;

        if (cameraclip && radius > 2.0f && radius < 10.0f)
            v7 += radius;

        const float distanceSq =
            v8 * v8 +
            v9 * v9 +
            v7 * v7;

        const float a2a = sqrtf(distanceSq);

        if (a2a <= 0.000001f)
            return 1;

        /*
            Game resolution.

            0xCBFB30 = width
            0xCBFB34 = height
        */
        const float width =
            static_cast<float>(patch::GetUInt(0xCBFB30));

        const float height =
            static_cast<float>(patch::GetUInt(0xCBFB34));

        float aspectScale = 1.0f;

        if (height > 0.0f)
        {
            const float aspect = width / height;

            /*
                NBA Live was designed around 4:3.
            */
            aspectScale = aspect / (4.0f / 3.0f);

            // Never make the original culling cone narrower.
            if (aspectScale < 1.0f)
                aspectScale = 1.0f;
        }

        /*
            Original expression simplifies to the negative dot product
            with the cone axis.

            _this[7..9] = mConeAxis.xyz
        */
        const float cameraclipa = -(
            v8 * _this[7] +
            v9 * _this[8] +
            v7 * _this[9]
            );

        /*
            Keep the original near/far depth test unchanged.

            _this[0] = mNearPlane
            _this[1] = mFarPlane
        */
        if (_this[0] - radius <= cameraclipa &&
            cameraclipa <= _this[1] + radius)
        {
            /*
                Original values:

                _this[2] = mConeSine
                _this[3] = mConeInvCosine

                tan(theta) = sin(theta) / cos(theta)
                           = mConeSine * mConeInvCosine
            */
            const float originalTan =
                _this[2] * _this[3];

            const float widescreenTan =
                originalTan * aspectScale;

            /*
                sec(theta) = sqrt(1 + tan^2(theta))
                sin(theta) = tan(theta) / sec(theta)
            */
            const float coneInvCosine =
                sqrtf(1.0f + widescreenTan * widescreenTan);

            const float coneSine =
                widescreenTan / coneInvCosine;

            /*
                Same role as original v6:
                    (depth * mConeSine + radius) * mConeInvCosine
            */
            const float v6 =
                (cameraclipa * coneSine + radius) *
                coneInvCosine;

            /*
                Squared distance perpendicular to cone axis.
            */
            const float cameraclipb =
                distanceSq -
                cameraclipa * cameraclipa;

            if (v6 * v6 > cameraclipb)
            {
                if (!cameraclip)
                    return 1;

                if (radius >= 10.0f)
                {
                    radius += 5.0f;
                }
                else if (0.25f * v6 * v6 > cameraclipb)
                {
                    /*
                        Original constant = 0.5f:
                        0.5^2 = 0.25
                    */
                    return 1;
                }

                if (a2a >= radius)
                    return 1;
            }
        }

        return 0;
    }


    // -------------------------------------------------------------------------
    // High-resolution APT RealFont rendering
    //
    // NBA Live 06 renders APT RealFont text through FontFusion into temporary
    // Text_N textures. The original game couples raster resolution, text-quad
    // size, and texture scale around a 480-line reference resolution.
    //
    // For higher resolutions:
    //   - rasterize the font at RES_Y / 480 resolution,
    //   - keep the APT text quad at its original logical size,
    //   - apply the reciprocal TextureScaleApt value,
    //   - report logical text bounds to controls that auto-size from text.
    //
    // Relevant original globals:
    //   0xC874C4 = size threshold (64)
    //   0xC874BC = RealFont X raster scale (~0.7071 above threshold)
    //   0xC874C0 = RealFont Y raster scale (~0.7071 above threshold)
    //
    // Relevant sub_7BDC00 instructions:
    //   0x7BE237 = fmul [var_27C]  (quad width)
    //   0x7BE254 = fmul [var_260]  (quad height)
    //   0x7BE7FC = mov [ebx+2Ch], 1.0f
    //   0x7BE803 = mov [ebx+30h], 1.0f
    // -------------------------------------------------------------------------
    static float gRealFontRasterScale06 = 1.0f;
    static DWORD gRealFontBoundsReturn06 = 0x007BE011;

    __declspec(naked) void RealFontLogicalAptBounds06()
    {
        __asm
        {
            // Original:
            // fild [esp+290h+var_274]
            //
            // var_274 is at ESP + 0x1C here.
            fild dword ptr[esp + 0x1C]

            // Convert supersampled measurement back to logical APT units.
            fdiv dword ptr[gRealFontRasterScale06]

                // Original positioning.
                fadd dword ptr[edi + 4]
                    fstp dword ptr[edi + 0x0C]

                    // Original:
                    // fild [esp+290h+var_25C]
                    //
                    // var_25C is at ESP + 0x34 here.
                    fild dword ptr[esp + 0x34]

                    // Important: preserve one copy of the ORIGINAL height on the FPU
                    // stack because stock code at 0x7BE01E subsequently scales it
                    // for the physical raster.
                    fld st(0)

                    // Only the copy used for the APT bottom bound is logicalized.
                    fdiv dword ptr[gRealFontRasterScale06]
                    fadd dword ptr[edi + 8]
                        fstp dword ptr[edi + 0x10]

                        // ST(0) is now still the original measured height, exactly as
                        // stock code expects when execution resumes at 0x7BE011.
                        jmp dword ptr[gRealFontBoundsReturn06]
        }
    }
    void InstallHighResolutionAptFonts06()
    {
        gRealFontRasterScale06 =
            static_cast<float>(RES_Y) / 480.0f;

        if (gRealFontRasterScale06 <= 0.0f)
            gRealFontRasterScale06 = 1.0f;

        const float fontTextureScale =
            1.0f / gRealFontRasterScale06;

        // Force all RealFonts through EA's scalable path.
        patch::SetUInt(0xC874C4, 0);

        // Higher-resolution FontFusion raster.
        patch::SetFloat(0xC874BC, gRealFontRasterScale06);
        patch::SetFloat(0xC874C0, gRealFontRasterScale06);

        // Keep rendered text quad at logical size.
        patch::Nop(0x7BE237, 4);
        patch::Nop(0x7BE254, 4);

        // Map the supersampled texture back onto the logical-size quad.
        patch::SetFloat(
            0x7BE7FF,
            fontTextureScale
        );

        patch::SetFloat(
            0x7BE806,
            fontTextureScale
        );

        // 007BD762:
        patch::SetUChar(0x7BD762, 0xB8);
        patch::SetUInt(0x7BD763, 0x3F800000);

        // 007BD77F:
        patch::SetUChar(0x7BD77F, 0xBA);
        patch::SetUInt(0x7BD780, 0x3F800000);
        patch::Nop(0x7BD784, 1);
        // Keep APT's reported text bounds at logical size so buttons,
        // backgrounds and other auto-sized elements don't grow with
        // the supersampled font texture.
        //
        // Replaces 0x7BDFFB through 0x7BE010 (0x16 bytes).
        patch::RedirectJump(
            0x7BDFFB,
            RealFontLogicalAptBounds06
        );

        // RedirectJump consumes the first 5 bytes; clear the rest.
        patch::Nop(0x7BE000, 0x11);
    }

    static void PatchResolutionMenuStrings06();
	
    // Function that scales UI components properly for widescreen
    DWORD METHOD FEAptInterface_Render(DWORD* t, DUMMY_ARG, char a1, int a2)
    {
        // The frontend has created its runtime copies of the stock resolution
        // labels by the time this render path is active. Retry until all ten
        // strings are patched, then this becomes a no-op.
        PatchResolutionMenuStrings06();

        int v3;
        float v4[17];
        float v5;
        char v6[64];
        float invX;
        float invY;
        float v7;
        float v9;
        float v10;

        v3 = CallAndReturn<int, 0x7D0D10>(); // 480
        v5 = CallAndReturn<int, 0x7D0D40>(); // 640
        invX = (double)v3 * 0.0015625f; // 640
        invY = (double)v5 * 0.0020833334f; // 480
        v10 = -0.5f;
        if (v3 / v5 > 1.3333334f)
        {
            v9 = invY;
            invX = (double)v3 * 0.0011709601f;
            v10 = 107.0 * invX - 0.5;
        }
        v4[0] = invX;
        v4[5] = invY;
        memset(&v4[1], 0, 16);
        memset(&v4[6], 0, 16);
        v4[10] = 1.0f;
        v4[11] = 0.0f;
        v4[12] = v10;
        v4[13] = -0.5f;
        v4[14] = -100.0f;
        v4[15] = 1.0f; // scale, it is scaled by 1/v4[15]
        void* camera = *raw_ptr<void*>(*(void**)0xCB2A6C, 28);
        CallMethod<0x6FBF14>(camera, &v3, v6);
        CallMethod<0x702731>(camera, &v3, v4);
        if (a1)
        {
            CallMethod<0x702684>(camera, &v3, 0xFFFFFFFF, 1);
        }
        Call<0x7ABA00>();
        return CallMethodAndReturn<DWORD, 0x702731>(camera, &v3, v6);
    }

    // Function that scales mouse position properly for widescreen
    int METHOD BroadcastMouseInput(int* _this)
    {
        int result; // eax
        int* v3; // edi
        int v4; // ebx
        int v5; // ebx
        int q6; // ebp
        int v7; // [esp+14h] [ebp-18h]
        int v8; // [esp+24h] [ebp-8h]
        int v12;

        int* pMouseDevice = *raw_ptr<int*>(_this, 0xC);
        result = *pMouseDevice;

        if (pMouseDevice)
        {
            v3 = CallAndReturn<int*, 0x624AC0>();
            v4 = CallVirtualMethodAndReturn<int, 2>(pMouseDevice, 3); // pMouseDevice->PeekInput(3)
            v12 = CallVirtualMethodAndReturn<int, 2>(pMouseDevice, 4);
            int* pBroadcast = *raw_ptr<int*>(v3, 0x4);
            int height = CallAndReturn<int, 0x7D0D40>();
            int width = CallAndReturn<int, 0x7D0D10>();
            double fWidth = (double)width;
            double fHeight = (double)height;
            if ((fWidth / fHeight) > 1.3333334f)
            {
                v7 = (int)(fWidth * 0.0011709601f * 107.0f);
                width -= 2 * v7;
                v4 -= v7;
            }
            v5 = 640 * v4 / width;
            v8 = 480 * v12 / height;
            if (CallVirtualMethodAndReturn<int, 14>(pMouseDevice, 1))
            {
                CallVirtualMethod<1>(v3, 130, 0, v5, v8, 0);
            }
            else if (CallVirtualMethodAndReturn<int, 15>(pMouseDevice, 1))
            {
                CallMethod<0x620D10>(v3, 131, 0, v5, v8, 0);
            }
            if (CallVirtualMethodAndReturn<int, 14>(pMouseDevice, 0))
            {
                CallVirtualMethod<1>(v3, 132, 0, v5, v8, 0);
            }
            else if (CallVirtualMethodAndReturn<int, 15>(pMouseDevice, 0))
            {
                CallMethod<0x620D10>(v3, 133, 0, v5, v8, 0);
            }
            q6 = CallVirtualMethodAndReturn<int, 2>(pMouseDevice, 0) != 0;
            if (CallVirtualMethodAndReturn<int, 2>(pMouseDevice, 2))
                q6 |= 4u;
            if (CallVirtualMethodAndReturn<int, 2>(pMouseDevice, 1))
                q6 |= 2u;
            return CallVirtualMethodAndReturn<int, 1>(v3, 128, 0, v5, v8, q6);
        }
        return result;
    }
    // Loadbar
    float loadXPos = ((212.0f / 640.0f) * (RES_Y * 1.33333f)) + ((RES_X - (RES_Y * 1.33333f)) / 2);
    float loadYPos = ((397.0f / 480.0f) * RES_Y);
    float loadWidth = 256.0f * (RES_Y / 480.0f);
    float loadHeight = 64.0f * (RES_Y / 480.0f);
    // Movies
    float CalculateAspectRatio() {

        // Check if aspect ratio is lower than 4:3 (1.333333f)
        if (ASPECT_RATIO < 1.333334f) {
            // If aspect ratio is lower, multiply 1.0 with (x / 640)
            return 1.0f * (RES_X / 640.0f);
        }
        // Check if aspect ratio is higher than 4:3 but lower than 16:9 (1.777777f)
        else if (ASPECT_RATIO > 1.333334f && ASPECT_RATIO <= 1.777777f) {
            // If aspect ratio is higher but lower, multiply 1.0 with (x / 640)
            return 1.0f * (RES_Y / 1088.0f);
        }
        // Check if aspect ratio is higher than 16:9
        else {
            // If aspect ratio is higher, multiply 1.0 with (y / 480)
            return 1.0f * (RES_X / 1920.0f);
        }
    }
    // CreationZone
    int czXPos = (int)(((362.0f / 640.0f) * (RES_Y * 1.33333f)) + ((RES_X - (RES_Y * 1.33333f)) / 2));
    int czYPos = (int)(((74.0f / 480.0f) * RES_Y));
    int czWidth = (int)((225.0f * (RES_Y / 480.0f)));
    int czHeight = (int)((303.0f * (RES_Y / 480.0f)));


    // -------------------------------------------------------------------------
    // NBA Live 06 runtime resolution-menu labels
    //
    // The real mode table at 0xC4CF38 is patched separately below. The
    // frontend later creates plain ANSI copies of the stock mode labels in
    // writable FE memory. These strings are not generated by the
    // $TXT_DTL_INGAME_RESOLUTION localization token; that token is only the
    // menu caption.
    //
    // Replace only exact stock video-mode strings in writable MEM_PRIVATE
    // regions. Every replacement is shorter than or equal to the original,
    // so no allocation or FEString layout changes are required.
    // -------------------------------------------------------------------------

    struct ResolutionStringRemap06
    {
        const char* oldText;
        const char* newText;
    };

    static const ResolutionStringRemap06 kResolutionStringRemaps06[] =
    {
        { "640x480x16",   "640x480"   },
        { "640x480x32",   "800x600"   },
        { "800x600x16",   "1024x768"  },
        { "800x600x32",   "1280x720"  },
        { "1024x768x16",  "1280x1024" },
        { "1024x768x32",  "1366x768"  },
        { "1280x1024x16", "1440x900"  },
        { "1280x1024x32", "1600x900"  },
        { "1600x1200x16", "1920x1080" },
        { "1600x1200x32", "2560x1440" },
    };

    static bool IsWritableFrontendMemory06(DWORD protect)
    {
        if (protect & PAGE_GUARD)
            return false;

        if (protect & PAGE_NOACCESS)
            return false;

        protect &= 0xFF;

        return
            protect == PAGE_READWRITE ||
            protect == PAGE_WRITECOPY ||
            protect == PAGE_EXECUTE_READWRITE ||
            protect == PAGE_EXECUTE_WRITECOPY;
    }

    static int ReplaceResolutionStringInRegion06(
        unsigned char* base,
        size_t size,
        const char* oldText,
        const char* newText)
    {
        if (!base || !oldText || !newText)
            return 0;

        const size_t oldLen = strlen(oldText);
        const size_t newLen = strlen(newText);

        if (oldLen == 0 || newLen > oldLen || size < oldLen + 1)
            return 0;

        int hits = 0;

        for (size_t i = 0; i + oldLen < size; ++i)
        {
            // Match the complete C string only.
            if (memcmp(base + i, oldText, oldLen) != 0)
                continue;

            if (base[i + oldLen] != '\0')
                continue;

            memset(base + i, 0, oldLen + 1);
            memcpy(base + i, newText, newLen);

            ++hits;
            i += oldLen;
        }

        return hits;
    }

    static int ReplaceResolutionStringEverywhere06(
        const char* oldText,
        const char* newText)
    {
        SYSTEM_INFO systemInfo{};
        GetSystemInfo(&systemInfo);

        uintptr_t address =
            reinterpret_cast<uintptr_t>(
                systemInfo.lpMinimumApplicationAddress);

        const uintptr_t maximumAddress =
            reinterpret_cast<uintptr_t>(
                systemInfo.lpMaximumApplicationAddress);

        int hits = 0;

        while (address < maximumAddress)
        {
            MEMORY_BASIC_INFORMATION mbi{};

            if (VirtualQuery(
                    reinterpret_cast<const void*>(address),
                    &mbi,
                    sizeof(mbi)) != sizeof(mbi))
            {
                break;
            }

            if (mbi.State == MEM_COMMIT &&
                mbi.Type == MEM_PRIVATE &&
                IsWritableFrontendMemory06(mbi.Protect))
            {
                hits += ReplaceResolutionStringInRegion06(
                    static_cast<unsigned char*>(mbi.BaseAddress),
                    static_cast<size_t>(mbi.RegionSize),
                    oldText,
                    newText);
            }

            const uintptr_t nextAddress =
                reinterpret_cast<uintptr_t>(mbi.BaseAddress) +
                static_cast<uintptr_t>(mbi.RegionSize);

            if (nextAddress <= address)
                break;

            address = nextAddress;
        }

        return hits;
    }

    static void PatchResolutionMenuStrings06()
    {
        static bool completed = false;

        if (completed)
            return;

        int totalHits = 0;

        for (const auto& remap : kResolutionStringRemaps06)
        {
            totalHits += ReplaceResolutionStringEverywhere06(
                remap.oldText,
                remap.newText);
        }

        // The frontend creates all ten stock entries together. Do not stop
        // retrying until all ten have been found at least once in the same
        // scan; this prevents an early startup call from permanently marking
        // the patch complete.
        if (totalHits >= 10)
            completed = true;
    }

    // Run the string replacement from a function that already executes every
    // frontend frame. This avoids startup-order assumptions and requires no
    // extra game hook solely for the labels.

}

void Install_LIVE06() {
    using namespace live06;
    // Change aspect ratio in-game
    patch::RedirectJump(0x70221E, SetPerspectiveProjection06);
    patch::RedirectJump(0x73E3C0, SetTestInConicalFrustum06);
    // High-resolution APT/RealFont rendering
    InstallHighResolutionAptFonts06();
    // Sets resolutions
    for (const auto& resolution : ids) {
        patch::SetUInt(0xC4CF38 + 20 * resolution.id + 4, resolution.width);
        patch::SetUInt(0xC4CF38 + 20 * resolution.id + 8, resolution.height);
        patch::SetUInt(0xC4CF38 + 20 * resolution.id + 12, resolution.depth);
    }
    // Changes size of windows
    patch::SetUInt(0x414C6C + 1, RES_Y);
    patch::SetUInt(0x414C71 + 1, RES_X);
    patch::SetUInt(0x41EAB0 + 1, RES_Y);
    patch::SetUInt(0x41EAB5 + 1, RES_X);
    patch::SetUInt(0x600216 + 1, RES_Y);
    patch::SetUInt(0x60021B + 1, RES_X);
    patch::SetUInt(0x606685 + 1, RES_Y);
    patch::SetUInt(0x60668A + 1, RES_X);
    patch::SetUInt(0x6F2EC5 + 1, RES_Y);
    patch::SetUInt(0x6F2ECA + 1, RES_X);
    patch::SetUInt(0x755E48 + 1, RES_Y);
    patch::SetUInt(0x755E4D + 1, RES_X);
    patch::SetUInt(0x7D1D6D + 1, RES_Y);
    patch::SetUInt(0x7D1D72 + 1, RES_X);
    patch::SetUInt(0x7D1DA2 + 1, RES_Y);
    patch::SetUInt(0x7D1DA7 + 1, RES_X);
    patch::SetUInt(0xC4CEDC, RES_X);
    patch::SetUInt(0xC4CEE0, RES_Y);
    // UI adjustment
    patch::RedirectJump(0x4BC4F0, FEAptInterface_Render);
    patch::RedirectJump(0x626600, BroadcastMouseInput);
    // loadbar
    patch::SetFloat(0xB83778 + 6, loadXPos);
    patch::SetFloat(0xB837B8 + 6, loadYPos);
    patch::SetFloat(0xB837F8 + 6, loadWidth);
    patch::SetFloat(0xB83838 + 6, loadHeight);
    // Movies
    if (INTRO == 1) {
        if (ASPECT_RATIO < 1.333334f) {
            patch::SetPointer(0x560A23 + 1, "EABRAND");
            patch::SetPointer(0x560CA1 + 1, "INTRO");
            patch::SetPointer(0x560C96 + 1, "INTRO");
            patch::SetPointer(0x598BDB + 1, "INTRO");
            patch::SetPointer(0x598BE2 + 1, "INTRO");
        }
        else {
            patch::SetPointer(0x560A23 + 1, "EABRANDWS");
            patch::SetPointer(0x560CA1 + 1, "INTROWS");
            patch::SetPointer(0x560C96 + 1, "INTROWS");
            patch::SetPointer(0x598BDB + 1, "INTROWS");
            patch::SetPointer(0x598BE2 + 1, "INTROWS");
        }
    }
    else {
        patch::SetPointer(0x560A23 + 1, "DUMMY");
        patch::SetPointer(0x560CA1 + 1, "DUMMY");
        patch::SetPointer(0x560C96 + 1, "DUMMY");
        patch::SetPointer(0x598BDB + 1, "DUMMY");
        patch::SetPointer(0x598BE2 + 1, "DUMMY");
    }
    patch::SetFloat(0x6364F4 + 1, CalculateAspectRatio());
    // CreateZone
    patch::SetUInt(0xB851C8 + 6, czXPos);
    patch::SetUInt(0xB85208 + 6, czYPos);
    patch::SetUInt(0xB85248 + 6, czWidth);
    patch::SetUInt(0xB85288 + 6, czHeight);

    // Switch UI files
    std::string pathA = ".\\assets\\06WSUI"; // Replace with the actual path 'a'
    std::string pathB = ".\\sgsm"; // Replace with the actual path 'b'
    adjustWSUI::adjustWidescreenUI(ASPECT_RATIO, pathA, pathB);

}

#include "plugin-std.h"
#include "Resolutions.h"
#include "ResolutionMenuStrings.h"

using namespace plugin;

const unsigned int RES_X = GetPrivateProfileIntW(L"DISPLAY", L"RES_X", 640, L".\\main.ini");
const unsigned int RES_Y = GetPrivateProfileIntW(L"DISPLAY", L"RES_Y", 480, L".\\main.ini");
const unsigned int INTRO = GetPrivateProfileIntW(L"BOOTUP", L"INTRO", 1, L".\\main.ini");
const float ASPECT_RATIO = static_cast<float>(RES_X) / static_cast<float>(RES_Y);
const float ASPECT_DIFF = ASPECT_RATIO / 1.33333f;
static float gAspectScale07 = 1.0f;

namespace live07 {

    static ResolutionMenuStringPatcher gResolutionMenuStrings07;

    // Logical menu order. NBA Live 07 has one important native invariant:
    // renderer mode index 1 is the startup/current mode. Do not fight that.
    //
    // Before patching the native table, PrepareResolutionSlots07() swaps the
    // configured RES_X/RES_Y mode into physical slot 1, then builds a mapping
    // that makes the Display Settings menu enumerate the modes in this logical
    // order.
    ResolutionID ids[] = {
        { 640,  480, 32, 0 },
        { 800,  600, 32, 1 },
        { 1024, 768, 32, 2 },
        { 1280, 720, 32, 3 },
        { 1280, 1024, 32, 4 },
        { 1366, 768, 32, 5 },
        { 1440, 900, 32, 6 },
        { 1600, 900, 32, 7 },
        { 1920, 1080, 32, 8 },
        { 2560, 1440, 32, 9 },
    };

    static unsigned int gResolutionMenuOrder07[10] = {
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9
    };

    static void PrepareResolutionSlots07()
    {
        int configuredLogicalIndex = -1;

        for (int i = 0; i < 10; ++i)
        {
            if (ids[i].width == RES_X &&
                ids[i].height == RES_Y)
            {
                configuredLogicalIndex = i;
                break;
            }
        }

        // If main.ini requests one of our ten exposed modes, keep NBA Live's
        // native startup invariant by placing that mode in physical slot 1.
        //
        // Swap only the mode values. The id member always remains the physical
        // native-table slot number.
        if (configuredLogicalIndex >= 0 &&
            configuredLogicalIndex != 1)
        {
            const unsigned int width = ids[1].width;
            const unsigned int height = ids[1].height;
            const unsigned int depth = ids[1].depth;

            ids[1].width = ids[configuredLogicalIndex].width;
            ids[1].height = ids[configuredLogicalIndex].height;
            ids[1].depth = ids[configuredLogicalIndex].depth;

            ids[configuredLogicalIndex].width = width;
            ids[configuredLogicalIndex].height = height;
            ids[configuredLogicalIndex].depth = depth;
        }

        // Desired visible menu order.
        static const unsigned int logicalWidth[10] = {
            640, 800, 1024, 1280, 1280,
            1366, 1440, 1600, 1920, 2560
        };

        static const unsigned int logicalHeight[10] = {
            480, 600, 768, 720, 1024,
            768, 900, 900, 1080, 1440
        };

        for (int logical = 0; logical < 10; ++logical)
        {
            gResolutionMenuOrder07[logical] =
                static_cast<unsigned int>(logical);

            for (int physical = 0; physical < 10; ++physical)
            {
                if (ids[physical].width == logicalWidth[logical] &&
                    ids[physical].height == logicalHeight[logical])
                {
                    gResolutionMenuOrder07[logical] =
                        static_cast<unsigned int>(physical);
                    break;
                }
            }
        }
    }

    // 0053A870 builds the list of supported resolution *indices*.
    // At 0053A8CF the stock code appends ESI (0..9), forcing physical table
    // order into the menu. Replace only that append operation with our logical
    // -> physical slot mapping. ESI remains untouched as the native loop
    // counter; EBX continues walking the physical table exactly as stock.
    static DWORD gResolutionMenuAppendReturn07 = 0x0053A8D4;

    __declspec(naked) static void AppendResolutionInLogicalOrder07()
    {
        __asm
        {
            mov edx, dword ptr [gResolutionMenuOrder07 + esi * 4]
            mov [edi], edx
            add edi, 4
            jmp dword ptr [gResolutionMenuAppendReturn07]
        }
    }

    DWORD* METHOD SetPerspectiveProjection07(
        float* _this, DUMMY_ARG,
        DWORD* a2,
        float fovY,
        float aspectRatio,
        float nearClip,
        float farClip)
    {
        const float w =
            static_cast<float>(*reinterpret_cast<unsigned int*>(_this + 2));

        const float h =
            static_cast<float>(*reinterpret_cast<unsigned int*>(_this + 3));

        if (h > 0.0f)
        {
            aspectRatio = w / h;

            gAspectScale07 =
                aspectRatio / (4.0f / 3.0f);

            if (gAspectScale07 < 1.0f)
                gAspectScale07 = 1.0f;
        }
        else
        {
            gAspectScale07 = 1.0f;
        }

        _this[15] = 0.0f;
        _this[6] = fovY;
        _this[7] = aspectRatio;
        _this[8] = nearClip;
        _this[9] = farClip;

        memcpy(_this + 36, (void*)0xBBC7B0, 0x40u);

        const double fovR =
            1.0 / tan(static_cast<double>(fovY) * 0.0087266462);

        _this[47] = -1.0f;

        _this[36] = static_cast<float>(
            0.5 * static_cast<double>(w) /
            static_cast<double>(aspectRatio) *
            fovR
            );

        _this[41] = static_cast<float>(
            -(static_cast<double>(h) * 0.5 * fovR)
            );

        _this[44] = static_cast<float>(
            static_cast<double>(w) * -0.5 -
            static_cast<double>(*reinterpret_cast<int*>(_this))
            );

        _this[45] = static_cast<float>(
            static_cast<double>(h) * -0.5 -
            static_cast<double>(*reinterpret_cast<int*>(_this + 1))
            );

        const double dist =
            static_cast<double>(nearClip) -
            static_cast<double>(farClip);

        _this[46] = static_cast<float>(
            static_cast<double>(nearClip) / dist - 1.0
            );

        _this[50] = static_cast<float>(
            static_cast<double>(nearClip) *
            static_cast<double>(farClip) / dist
            );

        CallMethod<0x439FEA>(_this, a2);

        return a2;
    }

    // NBA Live 07
    int SetTestInConicalFrustum07(
        float* a1,
        DUMMY_ARG,
        float radius,
        bool cameraclip)
    {
        const float dx =
            a1[0] - patch::GetFloat(0xCF0614);

        const float dy =
            a1[1] - patch::GetFloat(0xCF0618);

        const float dz =
            a1[2] - patch::GetFloat(0xCF061C);

        float testZ = dz;

        if (cameraclip && radius > 2.0f && radius < 10.0f)
            testZ += radius;

        const float distanceSq =
            dx * dx +
            dy * dy +
            testZ * testZ;

        const float distance =
            sqrtf(distanceSq);

        if (distance <= 0.000001f)
            return 1;

        const float depth = -(
            dx * patch::GetFloat(0xCF0620) +
            dy * patch::GetFloat(0xCF0624) +
            testZ * patch::GetFloat(0xCF0628)
            );

        if (patch::GetFloat(0xCF0604) - radius <= depth &&
            depth <= patch::GetFloat(0xCF0608) + radius)
        {
            const float originalConeSine =
                patch::GetFloat(0xCF060C);

            const float originalConeInvCosine =
                patch::GetFloat(0xCF0610);

            const float originalTan =
                originalConeSine *
                originalConeInvCosine;

            /*
                07's previous culling test used:

                    v5� > v12 * 0.33333

                Equivalent expansion:

                    1 / sqrt(0.33333)
                    ~= 1.73206

                Preserve that baseline and then add the
                widescreen aspect expansion.
            */
            constexpr float BASE_CULL_SCALE_07 =
                1.73205948f;

            const float widenedTan =
                originalTan *
                BASE_CULL_SCALE_07 *
                gAspectScale07;

            const float widenedConeInvCosine =
                sqrtf(
                    1.0f +
                    widenedTan * widenedTan
                );

            const float widenedConeSine =
                widenedTan /
                widenedConeInvCosine;

            const float coneRadius =
                (depth * widenedConeSine + radius) *
                widenedConeInvCosine;

            float radialDistanceSq =
                distanceSq -
                depth * depth;

            if (radialDistanceSq < 0.0f)
                radialDistanceSq = 0.0f;

            if (coneRadius * coneRadius > radialDistanceSq)
            {
                if (!cameraclip)
                    return 1;

                if (radius >= 10.0f)
                {
                    radius += 5.0f;
                }
                else if (
                    0.25f *
                    coneRadius *
                    coneRadius >
                    radialDistanceSq)
                {
                    return 1;
                }

                if (distance >= radius)
                    return 1;
            }
        }

        return 0;
    }

    static float gRealFontRasterScale07 = 1.0f;
    static DWORD gRealFontBoundsReturn07 = 0x0089DA41;

    __declspec(naked) void RealFontLogicalAptBounds07()
    {
        __asm
        {
            // Width returned by the supersampled text measurement.
            fild dword ptr[esp + 0x1C]

            // Convert only the APT-reported width back to logical units.
            fdiv dword ptr[gRealFontRasterScale07]

                fadd dword ptr[edi + 4]
                    fstp dword ptr[edi + 0x0C]

                    // Height returned by the supersampled text measurement.
                    fild dword ptr[esp + 0x34]

                    // Preserve the original physical height on the x87 stack.
                    //
                    // Stock code expects this value to remain in ST(0) when execution
                    // resumes at 0x89DA41, because the following raster-sizing code
                    // continues using it.
                    fld st(0)

                    // Logicalize only the copy used for the APT bounding rectangle.
                    fdiv dword ptr[gRealFontRasterScale07]

                    fadd dword ptr[edi + 8]
                        fstp dword ptr[edi + 0x10]

                        // ST(0) still contains the original unmodified physical height.
                        jmp dword ptr[gRealFontBoundsReturn07]
        }
    }

    void InstallHighResolutionAptFonts07()
    {
        gRealFontRasterScale07 =
            (RES_Y > 0)
            ? static_cast<float>(RES_Y) / 480.0f
            : 1.0f;

        if (gRealFontRasterScale07 <= 0.0f)
            gRealFontRasterScale07 = 1.0f;

        const float fontTextureScale =
            1.0f / gRealFontRasterScale07;


        // RealFont / TTF supersampling

        // Stock:
        // 0xCA0FF4 = large-font threshold
        // 0xCA0FEC = X raster scale
        // 0xCA0FF0 = Y raster scale
        // Force all RealFont sizes through the scalable path.
        patch::SetUInt(0xCA0FF4, 0);

        // Render the temporary Text_* backing texture at native-resolution scale.
        patch::SetFloat(
            0xCA0FEC,
            gRealFontRasterScale07
        );

        patch::SetFloat(
            0xCA0FF0,
            gRealFontRasterScale07
        );

        // ------------------------------------------------------------------------
        // Preserve logical text-quad dimensions
        // ------------------------------------------------------------------------
        // These would otherwise enlarge the generated text geometry by the same
        // factor used for the higher-resolution raster.
        patch::Nop(0x89DC67, 4);
        patch::Nop(0x89DC84, 4);

        // ------------------------------------------------------------------------
        // TextureScaleApt compensation
        // ------------------------------------------------------------------------
        // Stock:
        // 0089E22C  C7 43 2C 00 00 80 3F
        //           mov dword ptr [ebx+2Ch], 1.0f
        // 0089E233  C7 43 30 00 00 80 3F
        //           mov dword ptr [ebx+30h], 1.0f
        // The actual immediate operands begin at 0x89E22F / 0x89E236.
        patch::SetFloat(
            0x89E22F,
            fontTextureScale
        );

        patch::SetFloat(
            0x89E236,
            fontTextureScale
        );


        // ------------------------------------------------------------------------
        // Restore logical APT text bounds
        // ------------------------------------------------------------------------
        // Replaces:
        //     0x89DA2B .. 0x89DA40
        // Total length = 0x16 bytes.
        // RedirectJump consumes the first 5 bytes, so NOP the remaining 0x11.
        patch::RedirectJump(
            0x89DA2B,
            RealFontLogicalAptBounds07
        );

        patch::Nop(
            0x89DA30,
            0x11
        );
        // ------------------------------------------------------------------------
        // FFN / fixed-font isolation
        // ------------------------------------------------------------------------
        // sub_89D0D0 is the 07 equivalent of 06 sub_7BD6A0.
        // It also reads CA0FEC/CA0FF0. Those globals are now > 1.0 for RealFont
        // supersampling, but FFN fonts must NOT inherit that scale.
        // Force the two FFN-local scale values to 1.0f.


        // Original:
        // 0089D192  A1 EC 0F CA 00
        //           mov eax, dword_CA0FEC
        // Replace:
        // B8 00 00 80 3F
        // mov eax, 3F800000h
        patch::SetUChar(0x89D192, 0xB8);
        patch::SetUInt(0x89D193, 0x3F800000);


        // Original:
        // 0089D1AF  8B 15 F0 0F CA 00
        //           mov edx, dword_CA0FF0
        // Replace:
        // BA 00 00 80 3F
        // 90
        // mov edx, 3F800000h
        // nop
        patch::SetUChar(0x89D1AF, 0xBA);
        patch::SetUInt(0x89D1B0, 0x3F800000);
        patch::Nop(0x89D1B4, 1);
    }

    DWORD METHOD FEAptInterface_Render(DWORD* t, DUMMY_ARG, char a1, int a2)
    {
        int v3;
        float v4[17];
        float v5;
        char v6[64];
        float invX;
        float invY;
        float v7;
        float v9;
        float v10;

        DWORD* getResolution = (DWORD*)patch::GetPointer(0xD42568);
        DWORD* address = (DWORD*)patch::GetPointer(0xD42584);
        v3 = CallMethodAndReturn<int, 0x435953>((void*)getResolution);
        v5 = CallMethodAndReturn<int, 0x435956>(getResolution);
        invX = (double)v3 * 0.0015625f;
        invY = (double)v5 * 0.0020833334f;
        v10 = -0.5f;
        if (v3 / v5 > 1.3333334f)
        {
            v9 = invY;
            invX = (double)v3 * 0.0011709601f;
            v10 = 107.0f * invX - 0.5f;
        }
        v4[0] = invX;
        v4[5] = invY;
        memset(&v4[1], 0, 16);
        memset(&v4[6], 0, 16);
        v4[10] = 1.0f;
        v4[11] = 0.0f;
        v4[12] = v10;
        v4[13] = -0.5f;
        v4[14] = -100.0f;
        v4[15] = 1.0f;
        memcpy(v6, (const void*)(address + 80), sizeof(v6));;
        CallMethod<0x43A472>(address, &v3, v6);
        CallMethod<0x439024>(address, &v3, v4);
        if (a1)
        {
            v3 = -1;
            CallMethod<0x438F77>(address, &v3, 0xFFFFFFFF, 1);
        }
        Call<0x88B440>();
        return CallMethodAndReturn<DWORD, 0x439024>(address, &v3, v6);
    }

    __declspec(naked) void Live07MovieFilter()
    {
        __asm
        {
            // Original instruction
            mov ecx, [esp + 8]

            // EAX = movie ID returned by sub_501110.
            cmp eax, 1
            je skipMovie

            // Original movie playback.
            push eax
            mov edx, 0x0055C430
            call edx

            skipMovie :
            ret
        }
    }

    int METHOD BroadcastMouseInput(int* _this)
    {
        int result; // eax
        int* v3; // edi
        int v4; // ebx
        int v5; // ebx
        int q6; // ebp
        int v7; // [esp+14h] [ebp-18h]
        int v8; // [esp+24h] [ebp-8h]
        int v12;

        DWORD* getResolution = (DWORD*)patch::GetPointer(0xD42568);

        int* pMouseDevice = *raw_ptr<int*>(_this, 0xC);
        result = *pMouseDevice;

        if (pMouseDevice)
        {
            v3 = CallAndReturn<int*, 0x65C090>();
            v4 = CallVirtualMethodAndReturn<int, 2>(pMouseDevice, 3);
            v12 = CallVirtualMethodAndReturn<int, 2>(pMouseDevice, 4);
            int* pBroadcast = *raw_ptr<int*>(v3, 0x4);
            int height = CallMethodAndReturn<int, 0x435956>(getResolution);
            int width = CallMethodAndReturn<int, 0x435953>(getResolution);
            double fWidth = (double)width;
            double fHeight = (double)height;
            if ((fWidth / fHeight) > 1.3333334f)
            {
                v7 = (int)(fWidth * 0.0011709601f * 107.0f);
                width -= 2 * v7;
                v4 -= v7;
            }
            v5 = 640 * v4 / width;
            v8 = 480 * v12 / height;
            if (CallVirtualMethodAndReturn<int, 14>(pMouseDevice, 1))
            {
                CallVirtualMethod<1>(v3, 133, 0, v5, v8, 0);
            }
            else if (CallVirtualMethodAndReturn<int, 15>(pMouseDevice, 1))
            {
                CallMethod<0x657D30>(v3, 134, 0, v5, v8, 0);
            }
            if (CallVirtualMethodAndReturn<int, 14>(pMouseDevice, 0))
            {
                CallVirtualMethod<1>(v3, 135, 0, v5, v8, 0);
            }
            else if (CallVirtualMethodAndReturn<int, 15>(pMouseDevice, 0))
            {
                CallMethod<0x657D30>(v3, 136, 0, v5, v8, 0);
            }
            q6 = CallVirtualMethodAndReturn<int, 2>(pMouseDevice, 0) != 0;
            if (CallVirtualMethodAndReturn<int, 2>(pMouseDevice, 2))
                q6 |= 4u;
            if (CallVirtualMethodAndReturn<int, 2>(pMouseDevice, 1))
                q6 |= 2u;
            return CallVirtualMethodAndReturn<int, 1>(v3, 131, 0, v5, v8, q6);
        }
        return result;
    }
    // loadbar
    float loadXStart = ((66.0f / 640.0f) * (RES_Y * 1.33333f)) + ((RES_X - (RES_Y * 1.33333f)) / 2);
    float loadYStart = ((340.0f / 480.0f) * RES_Y);
    float loadXEnd = ((130.0f / 640.0f) * (RES_Y * 1.33333f)) + ((RES_X - (RES_Y * 1.33333f)) / 2);
    float loadYEnd = ((404.0f / 480.0f) * RES_Y);
    // CreationZone
    int czXPos = (int)(((362.0f / 640.0f) * (RES_Y * 1.33333f)) + ((RES_X - (RES_Y * 1.33333f)) / 2));
    int czYPos = (int)(((74.0f / 480.0f) * RES_Y));
    int czWidth = (int)((225.0f * (RES_Y / 480.0f)));
    int czHeight = (int)((303.0f * (RES_Y / 480.0f)));

}

void Install_LIVE07() {
    using namespace live07;
    patch::RedirectJump(0x438B11, SetPerspectiveProjection07);
    patch::RedirectJump(0x67BE80, SetTestInConicalFrustum07);
    InstallHighResolutionAptFonts07();

    // Preserve Live 07's native startup/current-mode slot (index 1), but
    // decouple menu ordering from physical table ordering.
    PrepareResolutionSlots07();

    // 53A8CF: mov [edi], esi / add edi, 4
    patch::RedirectJump(0x53A8CF, AppendResolutionInLogicalOrder07);

    // Capture the stock resolution labels before overwriting the mode table.
    gResolutionMenuStrings07.Initialize(
        0xC65CA0,
        ids,
        sizeof(ids) / sizeof(ids[0])
    );

    for (const auto& resolution : ids) {
        patch::SetUInt(0xC65CA0 + 20 * resolution.id + 4, resolution.width);
        patch::SetUInt(0xC65CA0 + 20 * resolution.id + 8, resolution.height);
        patch::SetUInt(0xC65CA0 + 20 * resolution.id + 12, resolution.depth);
    }
    patch::RedirectJump(0x4EAFA0, FEAptInterface_Render);
    patch::RedirectJump(0x65D820, BroadcastMouseInput);
    patch::SetUInt(0x414CFC + 1, RES_Y);
    patch::SetUInt(0x414D01 + 1, RES_X);
    patch::SetUInt(0x41E310 + 1, RES_Y);
    patch::SetUInt(0x41E315 + 1, RES_X);
    patch::SetUInt(0x42C47D + 1, RES_Y);
    patch::SetUInt(0x42C482 + 1, RES_X);
    patch::SetUInt(0x64AB40 + 1, RES_Y);
    patch::SetUInt(0x64AB45 + 1, RES_X);
    patch::SetUInt(0x9D91C2 + 1, RES_Y);
    patch::SetUInt(0x9D91C7 + 1, RES_X);
    // loadbar
    patch::SetFloat(0x63F932 + 4, loadXStart);
    patch::SetFloat(0x63F962 + 4, loadXStart);
    patch::SetFloat(0x63F93A + 4, loadYStart);
    patch::SetFloat(0x63F952 + 4, loadYStart);
    patch::SetFloat(0x63F94A + 4, loadXEnd);
    patch::SetFloat(0x63F97A + 4, loadXEnd);
    patch::SetFloat(0x63F96A + 4, loadYEnd);
    patch::SetFloat(0x63F982 + 4, loadYEnd);
    // enable/disable intro
    if (INTRO != 1) {
        patch::RedirectJump(0x005650AB, Live07MovieFilter);
        patch::SetPointer(0x560A23 + 1, "DUMMY");
        //patch::SetPointer(0x560C96 + 1, "DUMMY");
    }
    // CreateZone
    patch::SetUInt(0xC65D68, czXPos);
    patch::SetUInt(0xC65D6C, czYPos);
    patch::SetUInt(0xC65D70, czWidth);
    patch::SetUInt(0xC65D74, czHeight);

}
